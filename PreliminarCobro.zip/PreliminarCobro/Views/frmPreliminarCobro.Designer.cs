﻿namespace PreliminarCobro.Views
{
    partial class frmPreliminarCobro
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPreliminarCobro));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblCteBusca = new System.Windows.Forms.Label();
            this.pFiltros = new System.Windows.Forms.Panel();
            this.lblConvRD = new System.Windows.Forms.Label();
            this.lblCtaAsignada = new System.Windows.Forms.Label();
            this.lblCteIntervenido = new System.Windows.Forms.Label();
            this.btnHerramientas = new System.Windows.Forms.Button();
            this.cbBF = new System.Windows.Forms.CheckBox();
            this.lblTiempoConsulta = new System.Windows.Forms.Label();
            this.btnVerGenerarCobro = new System.Windows.Forms.Button();
            this.txtTiempoConsulta = new System.Windows.Forms.TextBox();
            this.lblCobXPolitica = new System.Windows.Forms.Label();
            this.lblConvLCT = new System.Windows.Forms.Label();
            this.lblHuellaSHM = new System.Windows.Forms.Label();
            this.lblCteCPBusca = new System.Windows.Forms.Label();
            this.txtCteCPBusca = new System.Windows.Forms.TextBox();
            this.lblCteTelBusca = new System.Windows.Forms.Label();
            this.txtCteTelBusca = new System.Windows.Forms.TextBox();
            this.lblCteDirBusca = new System.Windows.Forms.Label();
            this.txtCteDirBusca = new System.Windows.Forms.TextBox();
            this.lblCteNomBusca = new System.Windows.Forms.Label();
            this.txtCteNomBusca = new System.Windows.Forms.TextBox();
            this.txtCteBusca = new System.Windows.Forms.TextBox();
            this.scGeneral = new System.Windows.Forms.SplitContainer();
            this.txtPadreBonificacion = new System.Windows.Forms.TextBox();
            this.lblPadreBonificacion = new System.Windows.Forms.Label();
            this.txtPadreConvLCT = new System.Windows.Forms.TextBox();
            this.lblPadreConvLCT = new System.Windows.Forms.Label();
            this.txtPadreNHijos = new System.Windows.Forms.TextBox();
            this.lblPadreNHijos = new System.Windows.Forms.Label();
            this.txtPadreCobXPolitica = new System.Windows.Forms.TextBox();
            this.lblPadreCobXPolitica = new System.Windows.Forms.Label();
            this.lblPadreDiasVencido = new System.Windows.Forms.Label();
            this.txtPadreDiasVencido = new System.Windows.Forms.TextBox();
            this.lblPadreFechaEmision = new System.Windows.Forms.Label();
            this.txtPadreUltPago = new System.Windows.Forms.TextBox();
            this.lblPadreDiasInactivo = new System.Windows.Forms.Label();
            this.lblPadrePago = new System.Windows.Forms.Label();
            this.txtPadreFechaEmision = new System.Windows.Forms.TextBox();
            this.lblPadreSaldoTotal = new System.Windows.Forms.Label();
            this.txtPadreCondicion = new System.Windows.Forms.TextBox();
            this.lblPadreSaldoVencido = new System.Windows.Forms.Label();
            this.txtPadre1erVenc = new System.Windows.Forms.TextBox();
            this.lblPadreMoratorios = new System.Windows.Forms.Label();
            this.txtPadreSucursal = new System.Windows.Forms.TextBox();
            this.lblPadreSaldoCapital = new System.Windows.Forms.Label();
            this.txtPadreDiasInactivo = new System.Windows.Forms.TextBox();
            this.lblPadreImpVta = new System.Windows.Forms.Label();
            this.txtPadreCanalVenta = new System.Windows.Forms.TextBox();
            this.lblPadreCanalVenta = new System.Windows.Forms.Label();
            this.txtPadreImpVta = new System.Windows.Forms.TextBox();
            this.txtPadreSaldoCapital = new System.Windows.Forms.TextBox();
            this.lblPadreSucursal = new System.Windows.Forms.Label();
            this.txtPadreMoratorios = new System.Windows.Forms.TextBox();
            this.lblPadre1erVenc = new System.Windows.Forms.Label();
            this.txtPadreSaldoVencido = new System.Windows.Forms.TextBox();
            this.lblPadreUltPago = new System.Windows.Forms.Label();
            this.txtPadreSaldoTotal = new System.Windows.Forms.TextBox();
            this.lblPadreCondicion = new System.Windows.Forms.Label();
            this.txtPadrePago = new System.Windows.Forms.TextBox();
            this.gbInfoCte = new System.Windows.Forms.GroupBox();
            this.pGeneraCobro = new System.Windows.Forms.Panel();
            this.btnGenerarCobros = new System.Windows.Forms.Button();
            this.btnCancelaCobro = new System.Windows.Forms.Button();
            this.btnSalirCobro = new System.Windows.Forms.Button();
            this.btnAutCondonacion = new System.Windows.Forms.Button();
            this.btnQuitaSeguro = new System.Windows.Forms.Button();
            this.txtMovIdCobro = new System.Windows.Forms.TextBox();
            this.txtCobro = new System.Windows.Forms.TextBox();
            this.txtCambio = new System.Windows.Forms.TextBox();
            this.lblCambioN = new System.Windows.Forms.Label();
            this.txtImporteRecibido = new System.Windows.Forms.TextBox();
            this.lblImporteRecibidoN = new System.Windows.Forms.Label();
            this.txtTotalCobrar = new System.Windows.Forms.TextBox();
            this.lblTotalCobrarN = new System.Windows.Forms.Label();
            this.cbFormaPago = new System.Windows.Forms.ComboBox();
            this.lblFormaPagoN = new System.Windows.Forms.Label();
            this.lblMovIdCobroN = new System.Windows.Forms.Label();
            this.lblMovCobroN = new System.Windows.Forms.Label();
            this.lblFiltrosPadres = new System.Windows.Forms.Label();
            this.txtFiltrosPadres = new System.Windows.Forms.TextBox();
            this.lblBFCte = new System.Windows.Forms.Label();
            this.lblFechaServer = new System.Windows.Forms.Label();
            this.lblSaldoGlobalCte = new System.Windows.Forms.Label();
            this.lblBFCteN = new System.Windows.Forms.Label();
            this.lblSaldoFavorCte = new System.Windows.Forms.Label();
            this.lblComMayCte = new System.Windows.Forms.Label();
            this.lblSaldoGlobalCteN = new System.Windows.Forms.Label();
            this.lblSaldoFavorCteN = new System.Windows.Forms.Label();
            this.lblComMayCteN = new System.Windows.Forms.Label();
            this.lblCPCte = new System.Windows.Forms.Label();
            this.lblRCobCte = new System.Windows.Forms.Label();
            this.lblTelMovCte = new System.Windows.Forms.Label();
            this.lblTelPartCte = new System.Windows.Forms.Label();
            this.lblEstadoCte = new System.Windows.Forms.Label();
            this.lblPoblacionCte = new System.Windows.Forms.Label();
            this.lblColCte = new System.Windows.Forms.Label();
            this.lblDelegacionCte = new System.Windows.Forms.Label();
            this.lblDomCte = new System.Windows.Forms.Label();
            this.lblCGlobalCte = new System.Windows.Forms.Label();
            this.lblNomCte = new System.Windows.Forms.Label();
            this.lblCte2 = new System.Windows.Forms.Label();
            this.lblCGlobalCteN = new System.Windows.Forms.Label();
            this.lblCte2N = new System.Windows.Forms.Label();
            this.lblRCobCteN = new System.Windows.Forms.Label();
            this.lblTelMovCteN = new System.Windows.Forms.Label();
            this.lblTelPartCteN = new System.Windows.Forms.Label();
            this.lblEstadoCteN = new System.Windows.Forms.Label();
            this.lblCPCteN = new System.Windows.Forms.Label();
            this.lblPoblacionCteN = new System.Windows.Forms.Label();
            this.lblColCteN = new System.Windows.Forms.Label();
            this.lblDelegacionCteN = new System.Windows.Forms.Label();
            this.lblDomCteN = new System.Windows.Forms.Label();
            this.lblNomCteN = new System.Windows.Forms.Label();
            this.pDoctos = new System.Windows.Forms.Panel();
            this.scDoctos = new System.Windows.Forms.SplitContainer();
            this.tcDoctos = new System.Windows.Forms.TabControl();
            this.tpMenudeo = new System.Windows.Forms.TabPage();
            this.pPadres = new System.Windows.Forms.Panel();
            this.dgvPadres = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IdVta = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PadreMAVI = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PadreIDMAVI = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CteFinal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NombreBeneficiarioFinal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MovimientoPadre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiaPago = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LiquidaCon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PagoParaEstaralCorriente = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ImporteApoyo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SaldoApoyo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ImporteaPagar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ACondonar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DescripciondelArticulo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SolicitarApoyo = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.cmsMenuPadres = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.btnVerDetalle = new System.Windows.Forms.ToolStripMenuItem();
            this.btnOcultaDetalle = new System.Windows.Forms.ToolStripMenuItem();
            this.ssTotalesTab = new System.Windows.Forms.StatusStrip();
            this.lblTotalesCatCte = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblTabDoctos = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblTabCteFinalN = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblTabCteFinal = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblTabImpVtaN = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblTabImpVta = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblTabSaldoCapitalN = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblTabSaldoCapital = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblTabMoratoriosN = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblTabMoratorios = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblTabSaldoTotalN = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblTabSaldoTotal = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblTabSaldoVencidoN = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblTabSaldoVencido = new System.Windows.Forms.ToolStripStatusLabel();
            this.tpDima = new System.Windows.Forms.TabPage();
            this.tpInstituciones = new System.Windows.Forms.TabPage();
            this.tpMayoreo = new System.Windows.Forms.TabPage();
            this.tpApoyoCobDima = new System.Windows.Forms.TabPage();
            this.tpDineralia = new System.Windows.Forms.TabPage();
            this.tpCreditoEmpresario = new System.Windows.Forms.TabPage();
            this.pTotalesCte = new System.Windows.Forms.Panel();
            this.ssTotalesCte = new System.Windows.Forms.StatusStrip();
            this.lblTotDoctos = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblTotImpVtaN = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblTotImpVta = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblTotSaldoCapitalN = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblTotSaldoCapital = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblTotMoratoriosN = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblTotMoratorios = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblTotSaldoTotalN = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblTotSaldoTotal = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblTotSaldoVencidoN = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblTotSaldoVencido = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblTotalesCte = new System.Windows.Forms.Label();
            this.pHijos = new System.Windows.Forms.Panel();
            this.dgvHijos = new System.Windows.Forms.DataGridView();
            this.Movimiento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Vencimiento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Importe = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ImporteCPP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Saldo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiasVencidos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Origen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SaldoApoyoDIMA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ssPreliminar = new System.Windows.Forms.StatusStrip();
            this.lblUsuarioN = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblUsuario = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblNombreN = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblNombre = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblSucTrabajoN = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblSucTrabajo = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblEstTrabajoN = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblEstTrabajo = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblServerBase = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblVersionApp = new System.Windows.Forms.ToolStripStatusLabel();
            this.pFiltros.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scGeneral)).BeginInit();
            this.scGeneral.Panel1.SuspendLayout();
            this.scGeneral.Panel2.SuspendLayout();
            this.scGeneral.SuspendLayout();
            this.gbInfoCte.SuspendLayout();
            this.pGeneraCobro.SuspendLayout();
            this.pDoctos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scDoctos)).BeginInit();
            this.scDoctos.Panel1.SuspendLayout();
            this.scDoctos.Panel2.SuspendLayout();
            this.scDoctos.SuspendLayout();
            this.tcDoctos.SuspendLayout();
            this.tpMenudeo.SuspendLayout();
            this.pPadres.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPadres)).BeginInit();
            this.cmsMenuPadres.SuspendLayout();
            this.ssTotalesTab.SuspendLayout();
            this.pTotalesCte.SuspendLayout();
            this.ssTotalesCte.SuspendLayout();
            this.pHijos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHijos)).BeginInit();
            this.ssPreliminar.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblCteBusca
            // 
            this.lblCteBusca.AutoSize = true;
            this.lblCteBusca.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblCteBusca.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblCteBusca.Location = new System.Drawing.Point(3, 5);
            this.lblCteBusca.Name = "lblCteBusca";
            this.lblCteBusca.Size = new System.Drawing.Size(133, 14);
            this.lblCteBusca.TabIndex = 14;
            this.lblCteBusca.Text = "Buscar Cuenta / Tarjeta";
            // 
            // pFiltros
            // 
            this.pFiltros.BackColor = System.Drawing.Color.SteelBlue;
            this.pFiltros.Controls.Add(this.lblConvRD);
            this.pFiltros.Controls.Add(this.lblCtaAsignada);
            this.pFiltros.Controls.Add(this.lblCteIntervenido);
            this.pFiltros.Controls.Add(this.btnHerramientas);
            this.pFiltros.Controls.Add(this.cbBF);
            this.pFiltros.Controls.Add(this.lblTiempoConsulta);
            this.pFiltros.Controls.Add(this.btnVerGenerarCobro);
            this.pFiltros.Controls.Add(this.txtTiempoConsulta);
            this.pFiltros.Controls.Add(this.lblCobXPolitica);
            this.pFiltros.Controls.Add(this.lblConvLCT);
            this.pFiltros.Controls.Add(this.lblHuellaSHM);
            this.pFiltros.Controls.Add(this.lblCteCPBusca);
            this.pFiltros.Controls.Add(this.txtCteCPBusca);
            this.pFiltros.Controls.Add(this.lblCteTelBusca);
            this.pFiltros.Controls.Add(this.txtCteTelBusca);
            this.pFiltros.Controls.Add(this.lblCteDirBusca);
            this.pFiltros.Controls.Add(this.txtCteDirBusca);
            this.pFiltros.Controls.Add(this.lblCteNomBusca);
            this.pFiltros.Controls.Add(this.txtCteNomBusca);
            this.pFiltros.Controls.Add(this.txtCteBusca);
            this.pFiltros.Controls.Add(this.lblCteBusca);
            this.pFiltros.Dock = System.Windows.Forms.DockStyle.Top;
            this.pFiltros.Location = new System.Drawing.Point(0, 0);
            this.pFiltros.Name = "pFiltros";
            this.pFiltros.Size = new System.Drawing.Size(1008, 77);
            this.pFiltros.TabIndex = 110;
            // 
            // lblConvRD
            // 
            this.lblConvRD.AutoSize = true;
            this.lblConvRD.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConvRD.ForeColor = System.Drawing.Color.Red;
            this.lblConvRD.Location = new System.Drawing.Point(810, 17);
            this.lblConvRD.Name = "lblConvRD";
            this.lblConvRD.Size = new System.Drawing.Size(191, 14);
            this.lblConvRD.TabIndex = 61;
            this.lblConvRD.Text = "EL CLIENTE TIENE UN CONVENIO RD";
            this.lblConvRD.Visible = false;
            // 
            // lblCtaAsignada
            // 
            this.lblCtaAsignada.AutoSize = true;
            this.lblCtaAsignada.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCtaAsignada.ForeColor = System.Drawing.Color.Red;
            this.lblCtaAsignada.Location = new System.Drawing.Point(811, 4);
            this.lblCtaAsignada.Name = "lblCtaAsignada";
            this.lblCtaAsignada.Size = new System.Drawing.Size(135, 14);
            this.lblCtaAsignada.TabIndex = 60;
            this.lblCtaAsignada.Text = "CUENTA EN ASIGNACIÓN";
            this.lblCtaAsignada.Visible = false;
            // 
            // lblCteIntervenido
            // 
            this.lblCteIntervenido.AutoSize = true;
            this.lblCteIntervenido.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCteIntervenido.ForeColor = System.Drawing.Color.Red;
            this.lblCteIntervenido.Location = new System.Drawing.Point(409, 24);
            this.lblCteIntervenido.Name = "lblCteIntervenido";
            this.lblCteIntervenido.Size = new System.Drawing.Size(169, 14);
            this.lblCteIntervenido.TabIndex = 59;
            this.lblCteIntervenido.Text = "EL CLIENTE ESTA INTERVENIDO\r\n";
            this.lblCteIntervenido.Visible = false;
            // 
            // btnHerramientas
            // 
            this.btnHerramientas.BackColor = System.Drawing.Color.Azure;
            this.btnHerramientas.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHerramientas.FlatAppearance.BorderSize = 0;
            this.btnHerramientas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHerramientas.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnHerramientas.Image = ((System.Drawing.Image)(resources.GetObject("btnHerramientas.Image")));
            this.btnHerramientas.Location = new System.Drawing.Point(940, 33);
            this.btnHerramientas.Name = "btnHerramientas";
            this.btnHerramientas.Size = new System.Drawing.Size(40, 40);
            this.btnHerramientas.TabIndex = 58;
            this.btnHerramientas.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnHerramientas.UseVisualStyleBackColor = false;
            this.btnHerramientas.Click += new System.EventHandler(this.btn_Click);
            // 
            // cbBF
            // 
            this.cbBF.AutoSize = true;
            this.cbBF.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.cbBF.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.cbBF.Location = new System.Drawing.Point(142, 20);
            this.cbBF.Name = "cbBF";
            this.cbBF.Size = new System.Drawing.Size(119, 18);
            this.cbBF.TabIndex = 51;
            this.cbBF.Text = "Beneficiario Final";
            this.cbBF.UseVisualStyleBackColor = true;
            // 
            // lblTiempoConsulta
            // 
            this.lblTiempoConsulta.AutoSize = true;
            this.lblTiempoConsulta.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblTiempoConsulta.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblTiempoConsulta.Location = new System.Drawing.Point(715, 41);
            this.lblTiempoConsulta.Name = "lblTiempoConsulta";
            this.lblTiempoConsulta.Size = new System.Drawing.Size(101, 14);
            this.lblTiempoConsulta.TabIndex = 50;
            this.lblTiempoConsulta.Text = "Tiempo Consulta";
            // 
            // btnVerGenerarCobro
            // 
            this.btnVerGenerarCobro.BackColor = System.Drawing.Color.Transparent;
            this.btnVerGenerarCobro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVerGenerarCobro.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnVerGenerarCobro.FlatAppearance.BorderSize = 0;
            this.btnVerGenerarCobro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVerGenerarCobro.Font = new System.Drawing.Font("Arial", 7.5F, System.Drawing.FontStyle.Bold);
            this.btnVerGenerarCobro.ForeColor = System.Drawing.Color.White;
            this.btnVerGenerarCobro.Image = ((System.Drawing.Image)(resources.GetObject("btnVerGenerarCobro.Image")));
            this.btnVerGenerarCobro.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnVerGenerarCobro.Location = new System.Drawing.Point(828, 23);
            this.btnVerGenerarCobro.Name = "btnVerGenerarCobro";
            this.btnVerGenerarCobro.Size = new System.Drawing.Size(106, 50);
            this.btnVerGenerarCobro.TabIndex = 25;
            this.btnVerGenerarCobro.Text = "Generar Cobro\r\n(Ctrl-G)";
            this.btnVerGenerarCobro.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnVerGenerarCobro.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnVerGenerarCobro.UseVisualStyleBackColor = false;
            this.btnVerGenerarCobro.Click += new System.EventHandler(this.btnConCte_Click);
            // 
            // txtTiempoConsulta
            // 
            this.txtTiempoConsulta.BackColor = System.Drawing.SystemColors.Window;
            this.txtTiempoConsulta.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTiempoConsulta.Font = new System.Drawing.Font("Arial", 7.75F);
            this.txtTiempoConsulta.Location = new System.Drawing.Point(718, 55);
            this.txtTiempoConsulta.Name = "txtTiempoConsulta";
            this.txtTiempoConsulta.ReadOnly = true;
            this.txtTiempoConsulta.Size = new System.Drawing.Size(54, 19);
            this.txtTiempoConsulta.TabIndex = 49;
            this.txtTiempoConsulta.TabStop = false;
            this.txtTiempoConsulta.Text = "00:00.000";
            this.txtTiempoConsulta.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblCobXPolitica
            // 
            this.lblCobXPolitica.AutoSize = true;
            this.lblCobXPolitica.BackColor = System.Drawing.Color.SteelBlue;
            this.lblCobXPolitica.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCobXPolitica.ForeColor = System.Drawing.Color.Red;
            this.lblCobXPolitica.Location = new System.Drawing.Point(632, 24);
            this.lblCobXPolitica.Name = "lblCobXPolitica";
            this.lblCobXPolitica.Size = new System.Drawing.Size(104, 14);
            this.lblCobXPolitica.TabIndex = 32;
            this.lblCobXPolitica.Text = "APLICA BONIF I.M.";
            this.lblCobXPolitica.Visible = false;
            // 
            // lblConvLCT
            // 
            this.lblConvLCT.AutoSize = true;
            this.lblConvLCT.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConvLCT.ForeColor = System.Drawing.Color.Red;
            this.lblConvLCT.Location = new System.Drawing.Point(409, 4);
            this.lblConvLCT.Name = "lblConvLCT";
            this.lblConvLCT.Size = new System.Drawing.Size(199, 14);
            this.lblConvLCT.TabIndex = 31;
            this.lblConvLCT.Text = "EL CLIENTE TIENE UN CONVENIO LCT";
            this.lblConvLCT.Visible = false;
            // 
            // lblHuellaSHM
            // 
            this.lblHuellaSHM.AutoSize = true;
            this.lblHuellaSHM.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHuellaSHM.ForeColor = System.Drawing.Color.Red;
            this.lblHuellaSHM.Location = new System.Drawing.Point(632, 4);
            this.lblHuellaSHM.Name = "lblHuellaSHM";
            this.lblHuellaSHM.Size = new System.Drawing.Size(154, 14);
            this.lblHuellaSHM.TabIndex = 30;
            this.lblHuellaSHM.Text = "CAPTURAR HUELLA EN SHM";
            this.lblHuellaSHM.Visible = false;
            // 
            // lblCteCPBusca
            // 
            this.lblCteCPBusca.AutoSize = true;
            this.lblCteCPBusca.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblCteCPBusca.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblCteCPBusca.Location = new System.Drawing.Point(626, 41);
            this.lblCteCPBusca.Name = "lblCteCPBusca";
            this.lblCteCPBusca.Size = new System.Drawing.Size(86, 14);
            this.lblCteCPBusca.TabIndex = 29;
            this.lblCteCPBusca.Text = "Codigo  Postal";
            // 
            // txtCteCPBusca
            // 
            this.txtCteCPBusca.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCteCPBusca.Font = new System.Drawing.Font("Arial", 7.75F);
            this.txtCteCPBusca.Location = new System.Drawing.Point(629, 55);
            this.txtCteCPBusca.MaxLength = 7;
            this.txtCteCPBusca.Name = "txtCteCPBusca";
            this.txtCteCPBusca.ShortcutsEnabled = false;
            this.txtCteCPBusca.Size = new System.Drawing.Size(83, 19);
            this.txtCteCPBusca.TabIndex = 5;
            this.txtCteCPBusca.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCteCPBusca.TextChanged += new System.EventHandler(this.txt_TextChanged);
            this.txtCteCPBusca.Enter += new System.EventHandler(this.txt_Enter);
            this.txtCteCPBusca.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_KeyPress);
            // 
            // lblCteTelBusca
            // 
            this.lblCteTelBusca.AutoSize = true;
            this.lblCteTelBusca.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblCteTelBusca.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblCteTelBusca.Location = new System.Drawing.Point(501, 41);
            this.lblCteTelBusca.Name = "lblCteTelBusca";
            this.lblCteTelBusca.Size = new System.Drawing.Size(96, 14);
            this.lblCteTelBusca.TabIndex = 27;
            this.lblCteTelBusca.Text = "Buscar Teléfono";
            // 
            // txtCteTelBusca
            // 
            this.txtCteTelBusca.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCteTelBusca.Font = new System.Drawing.Font("Arial", 7.75F);
            this.txtCteTelBusca.Location = new System.Drawing.Point(504, 55);
            this.txtCteTelBusca.MaxLength = 10;
            this.txtCteTelBusca.Name = "txtCteTelBusca";
            this.txtCteTelBusca.ShortcutsEnabled = false;
            this.txtCteTelBusca.Size = new System.Drawing.Size(119, 19);
            this.txtCteTelBusca.TabIndex = 4;
            this.txtCteTelBusca.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCteTelBusca.TextChanged += new System.EventHandler(this.txt_TextChanged);
            this.txtCteTelBusca.Enter += new System.EventHandler(this.txt_Enter);
            this.txtCteTelBusca.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_KeyPress);
            // 
            // lblCteDirBusca
            // 
            this.lblCteDirBusca.AutoSize = true;
            this.lblCteDirBusca.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblCteDirBusca.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblCteDirBusca.Location = new System.Drawing.Point(251, 41);
            this.lblCteDirBusca.Name = "lblCteDirBusca";
            this.lblCteDirBusca.Size = new System.Drawing.Size(99, 14);
            this.lblCteDirBusca.TabIndex = 25;
            this.lblCteDirBusca.Text = "Buscar Dirección";
            // 
            // txtCteDirBusca
            // 
            this.txtCteDirBusca.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCteDirBusca.Font = new System.Drawing.Font("Arial", 7.75F);
            this.txtCteDirBusca.Location = new System.Drawing.Point(254, 55);
            this.txtCteDirBusca.MaxLength = 200;
            this.txtCteDirBusca.Name = "txtCteDirBusca";
            this.txtCteDirBusca.ShortcutsEnabled = false;
            this.txtCteDirBusca.Size = new System.Drawing.Size(244, 19);
            this.txtCteDirBusca.TabIndex = 3;
            this.txtCteDirBusca.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCteDirBusca.TextChanged += new System.EventHandler(this.txt_TextChanged);
            this.txtCteDirBusca.Enter += new System.EventHandler(this.txt_Enter);
            this.txtCteDirBusca.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_KeyPress);
            // 
            // lblCteNomBusca
            // 
            this.lblCteNomBusca.AutoSize = true;
            this.lblCteNomBusca.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblCteNomBusca.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblCteNomBusca.Location = new System.Drawing.Point(3, 41);
            this.lblCteNomBusca.Name = "lblCteNomBusca";
            this.lblCteNomBusca.Size = new System.Drawing.Size(247, 14);
            this.lblCteNomBusca.TabIndex = 23;
            this.lblCteNomBusca.Text = "Buscar Apellido Paterno, Materno y Nombre";
            // 
            // txtCteNomBusca
            // 
            this.txtCteNomBusca.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCteNomBusca.Font = new System.Drawing.Font("Arial", 7.75F);
            this.txtCteNomBusca.Location = new System.Drawing.Point(6, 55);
            this.txtCteNomBusca.MaxLength = 200;
            this.txtCteNomBusca.Name = "txtCteNomBusca";
            this.txtCteNomBusca.ShortcutsEnabled = false;
            this.txtCteNomBusca.Size = new System.Drawing.Size(242, 19);
            this.txtCteNomBusca.TabIndex = 2;
            this.txtCteNomBusca.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCteNomBusca.TextChanged += new System.EventHandler(this.txt_TextChanged);
            this.txtCteNomBusca.Enter += new System.EventHandler(this.txt_Enter);
            this.txtCteNomBusca.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_KeyPress);
            // 
            // txtCteBusca
            // 
            this.txtCteBusca.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCteBusca.Font = new System.Drawing.Font("Arial", 7.75F);
            this.txtCteBusca.Location = new System.Drawing.Point(6, 19);
            this.txtCteBusca.MaxLength = 22;
            this.txtCteBusca.Name = "txtCteBusca";
            this.txtCteBusca.Size = new System.Drawing.Size(129, 19);
            this.txtCteBusca.TabIndex = 1;
            this.txtCteBusca.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCteBusca.TextChanged += new System.EventHandler(this.txt_TextChanged);
            this.txtCteBusca.Enter += new System.EventHandler(this.txt_Enter);
            this.txtCteBusca.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_KeyPress);
            this.txtCteBusca.Leave += new System.EventHandler(this.txt_Leave);
            // 
            // scGeneral
            // 
            this.scGeneral.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.scGeneral.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scGeneral.Location = new System.Drawing.Point(0, 77);
            this.scGeneral.Name = "scGeneral";
            this.scGeneral.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // scGeneral.Panel1
            // 
            this.scGeneral.Panel1.BackColor = System.Drawing.Color.PaleGreen;
            this.scGeneral.Panel1.Controls.Add(this.txtPadreBonificacion);
            this.scGeneral.Panel1.Controls.Add(this.lblPadreBonificacion);
            this.scGeneral.Panel1.Controls.Add(this.txtPadreConvLCT);
            this.scGeneral.Panel1.Controls.Add(this.lblPadreConvLCT);
            this.scGeneral.Panel1.Controls.Add(this.txtPadreNHijos);
            this.scGeneral.Panel1.Controls.Add(this.lblPadreNHijos);
            this.scGeneral.Panel1.Controls.Add(this.txtPadreCobXPolitica);
            this.scGeneral.Panel1.Controls.Add(this.lblPadreCobXPolitica);
            this.scGeneral.Panel1.Controls.Add(this.lblPadreDiasVencido);
            this.scGeneral.Panel1.Controls.Add(this.txtPadreDiasVencido);
            this.scGeneral.Panel1.Controls.Add(this.lblPadreFechaEmision);
            this.scGeneral.Panel1.Controls.Add(this.txtPadreUltPago);
            this.scGeneral.Panel1.Controls.Add(this.lblPadreDiasInactivo);
            this.scGeneral.Panel1.Controls.Add(this.lblPadrePago);
            this.scGeneral.Panel1.Controls.Add(this.txtPadreFechaEmision);
            this.scGeneral.Panel1.Controls.Add(this.lblPadreSaldoTotal);
            this.scGeneral.Panel1.Controls.Add(this.txtPadreCondicion);
            this.scGeneral.Panel1.Controls.Add(this.lblPadreSaldoVencido);
            this.scGeneral.Panel1.Controls.Add(this.txtPadre1erVenc);
            this.scGeneral.Panel1.Controls.Add(this.lblPadreMoratorios);
            this.scGeneral.Panel1.Controls.Add(this.txtPadreSucursal);
            this.scGeneral.Panel1.Controls.Add(this.lblPadreSaldoCapital);
            this.scGeneral.Panel1.Controls.Add(this.txtPadreDiasInactivo);
            this.scGeneral.Panel1.Controls.Add(this.lblPadreImpVta);
            this.scGeneral.Panel1.Controls.Add(this.txtPadreCanalVenta);
            this.scGeneral.Panel1.Controls.Add(this.lblPadreCanalVenta);
            this.scGeneral.Panel1.Controls.Add(this.txtPadreImpVta);
            this.scGeneral.Panel1.Controls.Add(this.txtPadreSaldoCapital);
            this.scGeneral.Panel1.Controls.Add(this.lblPadreSucursal);
            this.scGeneral.Panel1.Controls.Add(this.txtPadreMoratorios);
            this.scGeneral.Panel1.Controls.Add(this.lblPadre1erVenc);
            this.scGeneral.Panel1.Controls.Add(this.txtPadreSaldoVencido);
            this.scGeneral.Panel1.Controls.Add(this.lblPadreUltPago);
            this.scGeneral.Panel1.Controls.Add(this.txtPadreSaldoTotal);
            this.scGeneral.Panel1.Controls.Add(this.lblPadreCondicion);
            this.scGeneral.Panel1.Controls.Add(this.txtPadrePago);
            this.scGeneral.Panel1.Controls.Add(this.gbInfoCte);
            // 
            // scGeneral.Panel2
            // 
            this.scGeneral.Panel2.Controls.Add(this.pDoctos);
            this.scGeneral.Size = new System.Drawing.Size(1008, 546);
            this.scGeneral.SplitterDistance = 239;
            this.scGeneral.SplitterWidth = 5;
            this.scGeneral.TabIndex = 24;
            this.scGeneral.TabStop = false;
            // 
            // txtPadreBonificacion
            // 
            this.txtPadreBonificacion.BackColor = System.Drawing.SystemColors.Window;
            this.txtPadreBonificacion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPadreBonificacion.Font = new System.Drawing.Font("Arial", 8F);
            this.txtPadreBonificacion.Location = new System.Drawing.Point(918, 182);
            this.txtPadreBonificacion.Name = "txtPadreBonificacion";
            this.txtPadreBonificacion.ReadOnly = true;
            this.txtPadreBonificacion.Size = new System.Drawing.Size(60, 20);
            this.txtPadreBonificacion.TabIndex = 97;
            this.txtPadreBonificacion.TabStop = false;
            this.txtPadreBonificacion.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblPadreBonificacion
            // 
            this.lblPadreBonificacion.AutoSize = true;
            this.lblPadreBonificacion.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblPadreBonificacion.Location = new System.Drawing.Point(821, 185);
            this.lblPadreBonificacion.Name = "lblPadreBonificacion";
            this.lblPadreBonificacion.Size = new System.Drawing.Size(73, 14);
            this.lblPadreBonificacion.TabIndex = 98;
            this.lblPadreBonificacion.Text = "Bonificación";
            // 
            // txtPadreConvLCT
            // 
            this.txtPadreConvLCT.BackColor = System.Drawing.SystemColors.Window;
            this.txtPadreConvLCT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPadreConvLCT.Font = new System.Drawing.Font("Arial", 8F);
            this.txtPadreConvLCT.Location = new System.Drawing.Point(759, 182);
            this.txtPadreConvLCT.Name = "txtPadreConvLCT";
            this.txtPadreConvLCT.ReadOnly = true;
            this.txtPadreConvLCT.Size = new System.Drawing.Size(60, 20);
            this.txtPadreConvLCT.TabIndex = 95;
            this.txtPadreConvLCT.TabStop = false;
            this.txtPadreConvLCT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblPadreConvLCT
            // 
            this.lblPadreConvLCT.AutoSize = true;
            this.lblPadreConvLCT.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblPadreConvLCT.Location = new System.Drawing.Point(663, 185);
            this.lblPadreConvLCT.Name = "lblPadreConvLCT";
            this.lblPadreConvLCT.Size = new System.Drawing.Size(84, 14);
            this.lblPadreConvLCT.TabIndex = 96;
            this.lblPadreConvLCT.Text = "Convenio LCT";
            // 
            // txtPadreNHijos
            // 
            this.txtPadreNHijos.BackColor = System.Drawing.SystemColors.Window;
            this.txtPadreNHijos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPadreNHijos.Font = new System.Drawing.Font("Arial", 8F);
            this.txtPadreNHijos.Location = new System.Drawing.Point(918, 160);
            this.txtPadreNHijos.Name = "txtPadreNHijos";
            this.txtPadreNHijos.ReadOnly = true;
            this.txtPadreNHijos.Size = new System.Drawing.Size(60, 20);
            this.txtPadreNHijos.TabIndex = 93;
            this.txtPadreNHijos.TabStop = false;
            this.txtPadreNHijos.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblPadreNHijos
            // 
            this.lblPadreNHijos.AutoSize = true;
            this.lblPadreNHijos.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblPadreNHijos.Location = new System.Drawing.Point(821, 163);
            this.lblPadreNHijos.Name = "lblPadreNHijos";
            this.lblPadreNHijos.Size = new System.Drawing.Size(36, 14);
            this.lblPadreNHijos.TabIndex = 94;
            this.lblPadreNHijos.Text = "# Doc";
            // 
            // txtPadreCobXPolitica
            // 
            this.txtPadreCobXPolitica.BackColor = System.Drawing.SystemColors.Window;
            this.txtPadreCobXPolitica.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPadreCobXPolitica.Font = new System.Drawing.Font("Arial", 8F);
            this.txtPadreCobXPolitica.Location = new System.Drawing.Point(918, 138);
            this.txtPadreCobXPolitica.Name = "txtPadreCobXPolitica";
            this.txtPadreCobXPolitica.ReadOnly = true;
            this.txtPadreCobXPolitica.Size = new System.Drawing.Size(60, 20);
            this.txtPadreCobXPolitica.TabIndex = 91;
            this.txtPadreCobXPolitica.TabStop = false;
            this.txtPadreCobXPolitica.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblPadreCobXPolitica
            // 
            this.lblPadreCobXPolitica.AutoSize = true;
            this.lblPadreCobXPolitica.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblPadreCobXPolitica.Location = new System.Drawing.Point(821, 141);
            this.lblPadreCobXPolitica.Name = "lblPadreCobXPolitica";
            this.lblPadreCobXPolitica.Size = new System.Drawing.Size(93, 14);
            this.lblPadreCobXPolitica.TabIndex = 92;
            this.lblPadreCobXPolitica.Text = "Aplica Bonif I.M.";
            // 
            // lblPadreDiasVencido
            // 
            this.lblPadreDiasVencido.AutoSize = true;
            this.lblPadreDiasVencido.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblPadreDiasVencido.Location = new System.Drawing.Point(663, 141);
            this.lblPadreDiasVencido.Name = "lblPadreDiasVencido";
            this.lblPadreDiasVencido.Size = new System.Drawing.Size(84, 14);
            this.lblPadreDiasVencido.TabIndex = 90;
            this.lblPadreDiasVencido.Text = "Días Vencidos";
            // 
            // txtPadreDiasVencido
            // 
            this.txtPadreDiasVencido.BackColor = System.Drawing.SystemColors.Window;
            this.txtPadreDiasVencido.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPadreDiasVencido.Font = new System.Drawing.Font("Arial", 8F);
            this.txtPadreDiasVencido.Location = new System.Drawing.Point(759, 138);
            this.txtPadreDiasVencido.Name = "txtPadreDiasVencido";
            this.txtPadreDiasVencido.ReadOnly = true;
            this.txtPadreDiasVencido.Size = new System.Drawing.Size(60, 20);
            this.txtPadreDiasVencido.TabIndex = 89;
            this.txtPadreDiasVencido.TabStop = false;
            this.txtPadreDiasVencido.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblPadreFechaEmision
            // 
            this.lblPadreFechaEmision.AutoSize = true;
            this.lblPadreFechaEmision.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblPadreFechaEmision.Location = new System.Drawing.Point(663, 9);
            this.lblPadreFechaEmision.Name = "lblPadreFechaEmision";
            this.lblPadreFechaEmision.Size = new System.Drawing.Size(86, 14);
            this.lblPadreFechaEmision.TabIndex = 75;
            this.lblPadreFechaEmision.Text = "Fecha Emisión";
            // 
            // txtPadreUltPago
            // 
            this.txtPadreUltPago.BackColor = System.Drawing.SystemColors.Window;
            this.txtPadreUltPago.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPadreUltPago.Font = new System.Drawing.Font("Arial", 8F);
            this.txtPadreUltPago.Location = new System.Drawing.Point(759, 50);
            this.txtPadreUltPago.Name = "txtPadreUltPago";
            this.txtPadreUltPago.ReadOnly = true;
            this.txtPadreUltPago.Size = new System.Drawing.Size(60, 20);
            this.txtPadreUltPago.TabIndex = 64;
            this.txtPadreUltPago.TabStop = false;
            this.txtPadreUltPago.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblPadreDiasInactivo
            // 
            this.lblPadreDiasInactivo.AutoSize = true;
            this.lblPadreDiasInactivo.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblPadreDiasInactivo.Location = new System.Drawing.Point(663, 119);
            this.lblPadreDiasInactivo.Name = "lblPadreDiasInactivo";
            this.lblPadreDiasInactivo.Size = new System.Drawing.Size(75, 14);
            this.lblPadreDiasInactivo.TabIndex = 80;
            this.lblPadreDiasInactivo.Text = "Días Inactivo";
            // 
            // lblPadrePago
            // 
            this.lblPadrePago.AutoSize = true;
            this.lblPadrePago.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblPadrePago.Location = new System.Drawing.Point(821, 119);
            this.lblPadrePago.Name = "lblPadrePago";
            this.lblPadrePago.Size = new System.Drawing.Size(76, 14);
            this.lblPadrePago.TabIndex = 87;
            this.lblPadrePago.Text = "Pago Normal";
            // 
            // txtPadreFechaEmision
            // 
            this.txtPadreFechaEmision.BackColor = System.Drawing.SystemColors.Window;
            this.txtPadreFechaEmision.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPadreFechaEmision.Font = new System.Drawing.Font("Arial", 8F);
            this.txtPadreFechaEmision.Location = new System.Drawing.Point(759, 6);
            this.txtPadreFechaEmision.Name = "txtPadreFechaEmision";
            this.txtPadreFechaEmision.ReadOnly = true;
            this.txtPadreFechaEmision.Size = new System.Drawing.Size(60, 20);
            this.txtPadreFechaEmision.TabIndex = 62;
            this.txtPadreFechaEmision.TabStop = false;
            this.txtPadreFechaEmision.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblPadreSaldoTotal
            // 
            this.lblPadreSaldoTotal.AutoSize = true;
            this.lblPadreSaldoTotal.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblPadreSaldoTotal.Location = new System.Drawing.Point(821, 75);
            this.lblPadreSaldoTotal.Name = "lblPadreSaldoTotal";
            this.lblPadreSaldoTotal.Size = new System.Drawing.Size(66, 14);
            this.lblPadreSaldoTotal.TabIndex = 86;
            this.lblPadreSaldoTotal.Text = "Saldo Total";
            // 
            // txtPadreCondicion
            // 
            this.txtPadreCondicion.BackColor = System.Drawing.SystemColors.Window;
            this.txtPadreCondicion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPadreCondicion.Font = new System.Drawing.Font("Arial", 8F);
            this.txtPadreCondicion.Location = new System.Drawing.Point(729, 28);
            this.txtPadreCondicion.Name = "txtPadreCondicion";
            this.txtPadreCondicion.ReadOnly = true;
            this.txtPadreCondicion.Size = new System.Drawing.Size(90, 20);
            this.txtPadreCondicion.TabIndex = 63;
            this.txtPadreCondicion.TabStop = false;
            this.txtPadreCondicion.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblPadreSaldoVencido
            // 
            this.lblPadreSaldoVencido.AutoSize = true;
            this.lblPadreSaldoVencido.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblPadreSaldoVencido.Location = new System.Drawing.Point(821, 97);
            this.lblPadreSaldoVencido.Name = "lblPadreSaldoVencido";
            this.lblPadreSaldoVencido.Size = new System.Drawing.Size(84, 14);
            this.lblPadreSaldoVencido.TabIndex = 85;
            this.lblPadreSaldoVencido.Text = "Saldo Vencido";
            // 
            // txtPadre1erVenc
            // 
            this.txtPadre1erVenc.BackColor = System.Drawing.SystemColors.Window;
            this.txtPadre1erVenc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPadre1erVenc.Font = new System.Drawing.Font("Arial", 8F);
            this.txtPadre1erVenc.Location = new System.Drawing.Point(759, 72);
            this.txtPadre1erVenc.Name = "txtPadre1erVenc";
            this.txtPadre1erVenc.ReadOnly = true;
            this.txtPadre1erVenc.Size = new System.Drawing.Size(60, 20);
            this.txtPadre1erVenc.TabIndex = 65;
            this.txtPadre1erVenc.TabStop = false;
            this.txtPadre1erVenc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblPadreMoratorios
            // 
            this.lblPadreMoratorios.AutoSize = true;
            this.lblPadreMoratorios.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblPadreMoratorios.Location = new System.Drawing.Point(821, 53);
            this.lblPadreMoratorios.Name = "lblPadreMoratorios";
            this.lblPadreMoratorios.Size = new System.Drawing.Size(68, 14);
            this.lblPadreMoratorios.TabIndex = 84;
            this.lblPadreMoratorios.Text = "Moratorios";
            // 
            // txtPadreSucursal
            // 
            this.txtPadreSucursal.BackColor = System.Drawing.SystemColors.Window;
            this.txtPadreSucursal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPadreSucursal.Font = new System.Drawing.Font("Arial", 8F);
            this.txtPadreSucursal.Location = new System.Drawing.Point(759, 94);
            this.txtPadreSucursal.Name = "txtPadreSucursal";
            this.txtPadreSucursal.ReadOnly = true;
            this.txtPadreSucursal.Size = new System.Drawing.Size(60, 20);
            this.txtPadreSucursal.TabIndex = 66;
            this.txtPadreSucursal.TabStop = false;
            this.txtPadreSucursal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblPadreSaldoCapital
            // 
            this.lblPadreSaldoCapital.AutoSize = true;
            this.lblPadreSaldoCapital.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblPadreSaldoCapital.Location = new System.Drawing.Point(821, 31);
            this.lblPadreSaldoCapital.Name = "lblPadreSaldoCapital";
            this.lblPadreSaldoCapital.Size = new System.Drawing.Size(77, 14);
            this.lblPadreSaldoCapital.TabIndex = 83;
            this.lblPadreSaldoCapital.Text = "Saldo Capital";
            // 
            // txtPadreDiasInactivo
            // 
            this.txtPadreDiasInactivo.BackColor = System.Drawing.SystemColors.Window;
            this.txtPadreDiasInactivo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPadreDiasInactivo.Font = new System.Drawing.Font("Arial", 8F);
            this.txtPadreDiasInactivo.Location = new System.Drawing.Point(759, 116);
            this.txtPadreDiasInactivo.Name = "txtPadreDiasInactivo";
            this.txtPadreDiasInactivo.ReadOnly = true;
            this.txtPadreDiasInactivo.Size = new System.Drawing.Size(60, 20);
            this.txtPadreDiasInactivo.TabIndex = 67;
            this.txtPadreDiasInactivo.TabStop = false;
            this.txtPadreDiasInactivo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblPadreImpVta
            // 
            this.lblPadreImpVta.AutoSize = true;
            this.lblPadreImpVta.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblPadreImpVta.Location = new System.Drawing.Point(821, 9);
            this.lblPadreImpVta.Name = "lblPadreImpVta";
            this.lblPadreImpVta.Size = new System.Drawing.Size(85, 14);
            this.lblPadreImpVta.TabIndex = 82;
            this.lblPadreImpVta.Text = "Importe Venta";
            // 
            // txtPadreCanalVenta
            // 
            this.txtPadreCanalVenta.BackColor = System.Drawing.SystemColors.Window;
            this.txtPadreCanalVenta.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPadreCanalVenta.Font = new System.Drawing.Font("Arial", 8F);
            this.txtPadreCanalVenta.Location = new System.Drawing.Point(759, 160);
            this.txtPadreCanalVenta.Name = "txtPadreCanalVenta";
            this.txtPadreCanalVenta.ReadOnly = true;
            this.txtPadreCanalVenta.Size = new System.Drawing.Size(60, 20);
            this.txtPadreCanalVenta.TabIndex = 68;
            this.txtPadreCanalVenta.TabStop = false;
            this.txtPadreCanalVenta.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblPadreCanalVenta
            // 
            this.lblPadreCanalVenta.AutoSize = true;
            this.lblPadreCanalVenta.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblPadreCanalVenta.Location = new System.Drawing.Point(663, 163);
            this.lblPadreCanalVenta.Name = "lblPadreCanalVenta";
            this.lblPadreCanalVenta.Size = new System.Drawing.Size(71, 14);
            this.lblPadreCanalVenta.TabIndex = 81;
            this.lblPadreCanalVenta.Text = "Canal Venta";
            // 
            // txtPadreImpVta
            // 
            this.txtPadreImpVta.BackColor = System.Drawing.SystemColors.Window;
            this.txtPadreImpVta.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPadreImpVta.Font = new System.Drawing.Font("Arial", 8F);
            this.txtPadreImpVta.Location = new System.Drawing.Point(918, 6);
            this.txtPadreImpVta.Name = "txtPadreImpVta";
            this.txtPadreImpVta.ReadOnly = true;
            this.txtPadreImpVta.Size = new System.Drawing.Size(60, 20);
            this.txtPadreImpVta.TabIndex = 69;
            this.txtPadreImpVta.TabStop = false;
            this.txtPadreImpVta.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtPadreSaldoCapital
            // 
            this.txtPadreSaldoCapital.BackColor = System.Drawing.SystemColors.Window;
            this.txtPadreSaldoCapital.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPadreSaldoCapital.Font = new System.Drawing.Font("Arial", 8F);
            this.txtPadreSaldoCapital.Location = new System.Drawing.Point(918, 28);
            this.txtPadreSaldoCapital.Name = "txtPadreSaldoCapital";
            this.txtPadreSaldoCapital.ReadOnly = true;
            this.txtPadreSaldoCapital.Size = new System.Drawing.Size(60, 20);
            this.txtPadreSaldoCapital.TabIndex = 70;
            this.txtPadreSaldoCapital.TabStop = false;
            this.txtPadreSaldoCapital.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblPadreSucursal
            // 
            this.lblPadreSucursal.AutoSize = true;
            this.lblPadreSucursal.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblPadreSucursal.Location = new System.Drawing.Point(663, 97);
            this.lblPadreSucursal.Name = "lblPadreSucursal";
            this.lblPadreSucursal.Size = new System.Drawing.Size(55, 14);
            this.lblPadreSucursal.TabIndex = 79;
            this.lblPadreSucursal.Text = "Sucursal";
            // 
            // txtPadreMoratorios
            // 
            this.txtPadreMoratorios.BackColor = System.Drawing.SystemColors.Window;
            this.txtPadreMoratorios.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPadreMoratorios.Font = new System.Drawing.Font("Arial", 8F);
            this.txtPadreMoratorios.Location = new System.Drawing.Point(918, 50);
            this.txtPadreMoratorios.Name = "txtPadreMoratorios";
            this.txtPadreMoratorios.ReadOnly = true;
            this.txtPadreMoratorios.Size = new System.Drawing.Size(60, 20);
            this.txtPadreMoratorios.TabIndex = 71;
            this.txtPadreMoratorios.TabStop = false;
            this.txtPadreMoratorios.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblPadre1erVenc
            // 
            this.lblPadre1erVenc.AutoSize = true;
            this.lblPadre1erVenc.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblPadre1erVenc.Location = new System.Drawing.Point(663, 75);
            this.lblPadre1erVenc.Name = "lblPadre1erVenc";
            this.lblPadre1erVenc.Size = new System.Drawing.Size(97, 14);
            this.lblPadre1erVenc.TabIndex = 78;
            this.lblPadre1erVenc.Text = "1er Vencimiento";
            // 
            // txtPadreSaldoVencido
            // 
            this.txtPadreSaldoVencido.BackColor = System.Drawing.SystemColors.Window;
            this.txtPadreSaldoVencido.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPadreSaldoVencido.Font = new System.Drawing.Font("Arial", 8F);
            this.txtPadreSaldoVencido.Location = new System.Drawing.Point(918, 94);
            this.txtPadreSaldoVencido.Name = "txtPadreSaldoVencido";
            this.txtPadreSaldoVencido.ReadOnly = true;
            this.txtPadreSaldoVencido.Size = new System.Drawing.Size(60, 20);
            this.txtPadreSaldoVencido.TabIndex = 72;
            this.txtPadreSaldoVencido.TabStop = false;
            this.txtPadreSaldoVencido.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblPadreUltPago
            // 
            this.lblPadreUltPago.AutoSize = true;
            this.lblPadreUltPago.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblPadreUltPago.Location = new System.Drawing.Point(663, 53);
            this.lblPadreUltPago.Name = "lblPadreUltPago";
            this.lblPadreUltPago.Size = new System.Drawing.Size(72, 14);
            this.lblPadreUltPago.TabIndex = 77;
            this.lblPadreUltPago.Text = "Ultimo Pago";
            // 
            // txtPadreSaldoTotal
            // 
            this.txtPadreSaldoTotal.BackColor = System.Drawing.SystemColors.Window;
            this.txtPadreSaldoTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPadreSaldoTotal.Font = new System.Drawing.Font("Arial", 8F);
            this.txtPadreSaldoTotal.Location = new System.Drawing.Point(918, 72);
            this.txtPadreSaldoTotal.Name = "txtPadreSaldoTotal";
            this.txtPadreSaldoTotal.ReadOnly = true;
            this.txtPadreSaldoTotal.Size = new System.Drawing.Size(60, 20);
            this.txtPadreSaldoTotal.TabIndex = 73;
            this.txtPadreSaldoTotal.TabStop = false;
            this.txtPadreSaldoTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblPadreCondicion
            // 
            this.lblPadreCondicion.AutoSize = true;
            this.lblPadreCondicion.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblPadreCondicion.Location = new System.Drawing.Point(663, 31);
            this.lblPadreCondicion.Name = "lblPadreCondicion";
            this.lblPadreCondicion.Size = new System.Drawing.Size(62, 14);
            this.lblPadreCondicion.TabIndex = 76;
            this.lblPadreCondicion.Text = "Condición";
            // 
            // txtPadrePago
            // 
            this.txtPadrePago.BackColor = System.Drawing.SystemColors.Window;
            this.txtPadrePago.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPadrePago.Font = new System.Drawing.Font("Arial", 8F);
            this.txtPadrePago.Location = new System.Drawing.Point(918, 116);
            this.txtPadrePago.Name = "txtPadrePago";
            this.txtPadrePago.ReadOnly = true;
            this.txtPadrePago.Size = new System.Drawing.Size(60, 20);
            this.txtPadrePago.TabIndex = 74;
            this.txtPadrePago.TabStop = false;
            this.txtPadrePago.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gbInfoCte
            // 
            this.gbInfoCte.BackColor = System.Drawing.Color.PaleGreen;
            this.gbInfoCte.Controls.Add(this.pGeneraCobro);
            this.gbInfoCte.Controls.Add(this.lblFiltrosPadres);
            this.gbInfoCte.Controls.Add(this.txtFiltrosPadres);
            this.gbInfoCte.Controls.Add(this.lblBFCte);
            this.gbInfoCte.Controls.Add(this.lblFechaServer);
            this.gbInfoCte.Controls.Add(this.lblSaldoGlobalCte);
            this.gbInfoCte.Controls.Add(this.lblBFCteN);
            this.gbInfoCte.Controls.Add(this.lblSaldoFavorCte);
            this.gbInfoCte.Controls.Add(this.lblComMayCte);
            this.gbInfoCte.Controls.Add(this.lblSaldoGlobalCteN);
            this.gbInfoCte.Controls.Add(this.lblSaldoFavorCteN);
            this.gbInfoCte.Controls.Add(this.lblComMayCteN);
            this.gbInfoCte.Controls.Add(this.lblCPCte);
            this.gbInfoCte.Controls.Add(this.lblRCobCte);
            this.gbInfoCte.Controls.Add(this.lblTelMovCte);
            this.gbInfoCte.Controls.Add(this.lblTelPartCte);
            this.gbInfoCte.Controls.Add(this.lblEstadoCte);
            this.gbInfoCte.Controls.Add(this.lblPoblacionCte);
            this.gbInfoCte.Controls.Add(this.lblColCte);
            this.gbInfoCte.Controls.Add(this.lblDelegacionCte);
            this.gbInfoCte.Controls.Add(this.lblDomCte);
            this.gbInfoCte.Controls.Add(this.lblCGlobalCte);
            this.gbInfoCte.Controls.Add(this.lblNomCte);
            this.gbInfoCte.Controls.Add(this.lblCte2);
            this.gbInfoCte.Controls.Add(this.lblCGlobalCteN);
            this.gbInfoCte.Controls.Add(this.lblCte2N);
            this.gbInfoCte.Controls.Add(this.lblRCobCteN);
            this.gbInfoCte.Controls.Add(this.lblTelMovCteN);
            this.gbInfoCte.Controls.Add(this.lblTelPartCteN);
            this.gbInfoCte.Controls.Add(this.lblEstadoCteN);
            this.gbInfoCte.Controls.Add(this.lblCPCteN);
            this.gbInfoCte.Controls.Add(this.lblPoblacionCteN);
            this.gbInfoCte.Controls.Add(this.lblColCteN);
            this.gbInfoCte.Controls.Add(this.lblDelegacionCteN);
            this.gbInfoCte.Controls.Add(this.lblDomCteN);
            this.gbInfoCte.Controls.Add(this.lblNomCteN);
            this.gbInfoCte.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.gbInfoCte.Location = new System.Drawing.Point(4, 5);
            this.gbInfoCte.Name = "gbInfoCte";
            this.gbInfoCte.Size = new System.Drawing.Size(653, 178);
            this.gbInfoCte.TabIndex = 26;
            this.gbInfoCte.TabStop = false;
            this.gbInfoCte.Text = "Información del Cliente";
            // 
            // pGeneraCobro
            // 
            this.pGeneraCobro.Controls.Add(this.btnGenerarCobros);
            this.pGeneraCobro.Controls.Add(this.btnCancelaCobro);
            this.pGeneraCobro.Controls.Add(this.btnSalirCobro);
            this.pGeneraCobro.Controls.Add(this.btnAutCondonacion);
            this.pGeneraCobro.Controls.Add(this.btnQuitaSeguro);
            this.pGeneraCobro.Controls.Add(this.txtMovIdCobro);
            this.pGeneraCobro.Controls.Add(this.txtCobro);
            this.pGeneraCobro.Controls.Add(this.txtCambio);
            this.pGeneraCobro.Controls.Add(this.lblCambioN);
            this.pGeneraCobro.Controls.Add(this.txtImporteRecibido);
            this.pGeneraCobro.Controls.Add(this.lblImporteRecibidoN);
            this.pGeneraCobro.Controls.Add(this.txtTotalCobrar);
            this.pGeneraCobro.Controls.Add(this.lblTotalCobrarN);
            this.pGeneraCobro.Controls.Add(this.cbFormaPago);
            this.pGeneraCobro.Controls.Add(this.lblFormaPagoN);
            this.pGeneraCobro.Controls.Add(this.lblMovIdCobroN);
            this.pGeneraCobro.Controls.Add(this.lblMovCobroN);
            this.pGeneraCobro.Location = new System.Drawing.Point(5, 42);
            this.pGeneraCobro.Name = "pGeneraCobro";
            this.pGeneraCobro.Size = new System.Drawing.Size(648, 110);
            this.pGeneraCobro.TabIndex = 40;
            this.pGeneraCobro.Visible = false;
            // 
            // btnGenerarCobros
            // 
            this.btnGenerarCobros.BackColor = System.Drawing.Color.Transparent;
            this.btnGenerarCobros.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGenerarCobros.FlatAppearance.BorderSize = 0;
            this.btnGenerarCobros.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGenerarCobros.Font = new System.Drawing.Font("Arial", 7.5F, System.Drawing.FontStyle.Bold);
            this.btnGenerarCobros.Image = ((System.Drawing.Image)(resources.GetObject("btnGenerarCobros.Image")));
            this.btnGenerarCobros.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnGenerarCobros.Location = new System.Drawing.Point(218, 2);
            this.btnGenerarCobros.Name = "btnGenerarCobros";
            this.btnGenerarCobros.Size = new System.Drawing.Size(98, 52);
            this.btnGenerarCobros.TabIndex = 3;
            this.btnGenerarCobros.Text = "Afectar Cobro\r\n(ALT-&F)";
            this.btnGenerarCobros.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGenerarCobros.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnGenerarCobros.UseVisualStyleBackColor = false;
            this.btnGenerarCobros.Click += new System.EventHandler(this.btnConCte_Click);
            // 
            // btnCancelaCobro
            // 
            this.btnCancelaCobro.BackColor = System.Drawing.Color.Transparent;
            this.btnCancelaCobro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancelaCobro.FlatAppearance.BorderSize = 0;
            this.btnCancelaCobro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelaCobro.Font = new System.Drawing.Font("Arial", 7.5F, System.Drawing.FontStyle.Bold);
            this.btnCancelaCobro.Image = ((System.Drawing.Image)(resources.GetObject("btnCancelaCobro.Image")));
            this.btnCancelaCobro.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnCancelaCobro.Location = new System.Drawing.Point(202, 6);
            this.btnCancelaCobro.Name = "btnCancelaCobro";
            this.btnCancelaCobro.Size = new System.Drawing.Size(99, 45);
            this.btnCancelaCobro.TabIndex = 38;
            this.btnCancelaCobro.Text = "Cancelar Cobro\r\n(ALT-&C)";
            this.btnCancelaCobro.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelaCobro.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnCancelaCobro.UseVisualStyleBackColor = false;
            this.btnCancelaCobro.Click += new System.EventHandler(this.btnConCte_Click);
            // 
            // btnSalirCobro
            // 
            this.btnSalirCobro.BackColor = System.Drawing.Color.Transparent;
            this.btnSalirCobro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSalirCobro.FlatAppearance.BorderSize = 0;
            this.btnSalirCobro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalirCobro.Font = new System.Drawing.Font("Arial", 7.5F, System.Drawing.FontStyle.Bold);
            this.btnSalirCobro.Image = ((System.Drawing.Image)(resources.GetObject("btnSalirCobro.Image")));
            this.btnSalirCobro.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnSalirCobro.Location = new System.Drawing.Point(567, 53);
            this.btnSalirCobro.Name = "btnSalirCobro";
            this.btnSalirCobro.Size = new System.Drawing.Size(72, 56);
            this.btnSalirCobro.TabIndex = 6;
            this.btnSalirCobro.Text = "Regresar";
            this.btnSalirCobro.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSalirCobro.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnSalirCobro.UseVisualStyleBackColor = false;
            this.btnSalirCobro.Click += new System.EventHandler(this.btnConCte_Click);
            // 
            // btnAutCondonacion
            // 
            this.btnAutCondonacion.BackColor = System.Drawing.Color.Transparent;
            this.btnAutCondonacion.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAutCondonacion.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnAutCondonacion.FlatAppearance.BorderSize = 0;
            this.btnAutCondonacion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAutCondonacion.Font = new System.Drawing.Font("Arial", 7.5F, System.Drawing.FontStyle.Bold);
            this.btnAutCondonacion.Image = ((System.Drawing.Image)(resources.GetObject("btnAutCondonacion.Image")));
            this.btnAutCondonacion.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnAutCondonacion.Location = new System.Drawing.Point(347, 1);
            this.btnAutCondonacion.Name = "btnAutCondonacion";
            this.btnAutCondonacion.Size = new System.Drawing.Size(137, 52);
            this.btnAutCondonacion.TabIndex = 4;
            this.btnAutCondonacion.Text = "Autorizar Condonación\r\n(ALT-&A)";
            this.btnAutCondonacion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAutCondonacion.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAutCondonacion.UseVisualStyleBackColor = false;
            this.btnAutCondonacion.Click += new System.EventHandler(this.btnConCte_Click);
            // 
            // btnQuitaSeguro
            // 
            this.btnQuitaSeguro.BackColor = System.Drawing.Color.Transparent;
            this.btnQuitaSeguro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnQuitaSeguro.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnQuitaSeguro.FlatAppearance.BorderSize = 0;
            this.btnQuitaSeguro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQuitaSeguro.Font = new System.Drawing.Font("Arial", 7.5F, System.Drawing.FontStyle.Bold);
            this.btnQuitaSeguro.Image = ((System.Drawing.Image)(resources.GetObject("btnQuitaSeguro.Image")));
            this.btnQuitaSeguro.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnQuitaSeguro.Location = new System.Drawing.Point(511, 2);
            this.btnQuitaSeguro.Name = "btnQuitaSeguro";
            this.btnQuitaSeguro.Size = new System.Drawing.Size(125, 52);
            this.btnQuitaSeguro.TabIndex = 5;
            this.btnQuitaSeguro.Text = "Quitar Cobro Seguro\r\n(ALT-&Q)";
            this.btnQuitaSeguro.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnQuitaSeguro.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnQuitaSeguro.UseVisualStyleBackColor = false;
            this.btnQuitaSeguro.Click += new System.EventHandler(this.btnConCte_Click);
            // 
            // txtMovIdCobro
            // 
            this.txtMovIdCobro.BackColor = System.Drawing.SystemColors.Window;
            this.txtMovIdCobro.Location = new System.Drawing.Point(73, 16);
            this.txtMovIdCobro.Name = "txtMovIdCobro";
            this.txtMovIdCobro.ReadOnly = true;
            this.txtMovIdCobro.Size = new System.Drawing.Size(127, 22);
            this.txtMovIdCobro.TabIndex = 31;
            this.txtMovIdCobro.TabStop = false;
            this.txtMovIdCobro.Text = "Cobro";
            // 
            // txtCobro
            // 
            this.txtCobro.BackColor = System.Drawing.SystemColors.Window;
            this.txtCobro.Location = new System.Drawing.Point(6, 16);
            this.txtCobro.Name = "txtCobro";
            this.txtCobro.ReadOnly = true;
            this.txtCobro.Size = new System.Drawing.Size(55, 22);
            this.txtCobro.TabIndex = 30;
            this.txtCobro.TabStop = false;
            this.txtCobro.Text = "Cobro";
            // 
            // txtCambio
            // 
            this.txtCambio.BackColor = System.Drawing.SystemColors.Window;
            this.txtCambio.Location = new System.Drawing.Point(461, 84);
            this.txtCambio.Name = "txtCambio";
            this.txtCambio.ReadOnly = true;
            this.txtCambio.ShortcutsEnabled = false;
            this.txtCambio.Size = new System.Drawing.Size(100, 22);
            this.txtCambio.TabIndex = 29;
            this.txtCambio.TabStop = false;
            this.txtCambio.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblCambioN
            // 
            this.lblCambioN.AutoSize = true;
            this.lblCambioN.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold);
            this.lblCambioN.Location = new System.Drawing.Point(408, 88);
            this.lblCambioN.Name = "lblCambioN";
            this.lblCambioN.Size = new System.Drawing.Size(53, 15);
            this.lblCambioN.TabIndex = 28;
            this.lblCambioN.Text = "Cambio:";
            // 
            // txtImporteRecibido
            // 
            this.txtImporteRecibido.BackColor = System.Drawing.SystemColors.Window;
            this.txtImporteRecibido.Location = new System.Drawing.Point(302, 84);
            this.txtImporteRecibido.Name = "txtImporteRecibido";
            this.txtImporteRecibido.ShortcutsEnabled = false;
            this.txtImporteRecibido.Size = new System.Drawing.Size(100, 22);
            this.txtImporteRecibido.TabIndex = 1;
            this.txtImporteRecibido.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtImporteRecibido.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_KeyPress);
            this.txtImporteRecibido.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txt_KeyUp);
            this.txtImporteRecibido.Validated += new System.EventHandler(this.txt_Validated);
            // 
            // lblImporteRecibidoN
            // 
            this.lblImporteRecibidoN.AutoSize = true;
            this.lblImporteRecibidoN.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold);
            this.lblImporteRecibidoN.Location = new System.Drawing.Point(197, 88);
            this.lblImporteRecibidoN.Name = "lblImporteRecibidoN";
            this.lblImporteRecibidoN.Size = new System.Drawing.Size(106, 15);
            this.lblImporteRecibidoN.TabIndex = 26;
            this.lblImporteRecibidoN.Text = "Importe Recibido:";
            // 
            // txtTotalCobrar
            // 
            this.txtTotalCobrar.BackColor = System.Drawing.SystemColors.Window;
            this.txtTotalCobrar.Location = new System.Drawing.Point(91, 84);
            this.txtTotalCobrar.Name = "txtTotalCobrar";
            this.txtTotalCobrar.ReadOnly = true;
            this.txtTotalCobrar.ShortcutsEnabled = false;
            this.txtTotalCobrar.Size = new System.Drawing.Size(100, 22);
            this.txtTotalCobrar.TabIndex = 25;
            this.txtTotalCobrar.TabStop = false;
            this.txtTotalCobrar.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblTotalCobrarN
            // 
            this.lblTotalCobrarN.AutoSize = true;
            this.lblTotalCobrarN.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold);
            this.lblTotalCobrarN.Location = new System.Drawing.Point(3, 88);
            this.lblTotalCobrarN.Name = "lblTotalCobrarN";
            this.lblTotalCobrarN.Size = new System.Drawing.Size(89, 15);
            this.lblTotalCobrarN.TabIndex = 24;
            this.lblTotalCobrarN.Text = "Total a Cobrar:";
            // 
            // cbFormaPago
            // 
            this.cbFormaPago.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbFormaPago.Font = new System.Drawing.Font("Arial", 9.75F);
            this.cbFormaPago.FormattingEnabled = true;
            this.cbFormaPago.Location = new System.Drawing.Point(6, 56);
            this.cbFormaPago.Name = "cbFormaPago";
            this.cbFormaPago.Size = new System.Drawing.Size(293, 24);
            this.cbFormaPago.TabIndex = 2;
            // 
            // lblFormaPagoN
            // 
            this.lblFormaPagoN.AutoSize = true;
            this.lblFormaPagoN.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold);
            this.lblFormaPagoN.Location = new System.Drawing.Point(3, 40);
            this.lblFormaPagoN.Name = "lblFormaPagoN";
            this.lblFormaPagoN.Size = new System.Drawing.Size(95, 15);
            this.lblFormaPagoN.TabIndex = 22;
            this.lblFormaPagoN.Text = "Forma de Pago:";
            // 
            // lblMovIdCobroN
            // 
            this.lblMovIdCobroN.AutoSize = true;
            this.lblMovIdCobroN.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold);
            this.lblMovIdCobroN.Location = new System.Drawing.Point(70, 1);
            this.lblMovIdCobroN.Name = "lblMovIdCobroN";
            this.lblMovIdCobroN.Size = new System.Drawing.Size(44, 15);
            this.lblMovIdCobroN.TabIndex = 20;
            this.lblMovIdCobroN.Text = "MovID:";
            // 
            // lblMovCobroN
            // 
            this.lblMovCobroN.AutoSize = true;
            this.lblMovCobroN.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold);
            this.lblMovCobroN.Location = new System.Drawing.Point(3, 1);
            this.lblMovCobroN.Name = "lblMovCobroN";
            this.lblMovCobroN.Size = new System.Drawing.Size(33, 15);
            this.lblMovCobroN.TabIndex = 18;
            this.lblMovCobroN.Text = "Mov:";
            // 
            // lblFiltrosPadres
            // 
            this.lblFiltrosPadres.AutoSize = true;
            this.lblFiltrosPadres.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblFiltrosPadres.Location = new System.Drawing.Point(6, 158);
            this.lblFiltrosPadres.Name = "lblFiltrosPadres";
            this.lblFiltrosPadres.Size = new System.Drawing.Size(256, 14);
            this.lblFiltrosPadres.TabIndex = 61;
            this.lblFiltrosPadres.Text = "Buscar por MovID, Nom. Cte Final ó Descripción Art.";
            // 
            // txtFiltrosPadres
            // 
            this.txtFiltrosPadres.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtFiltrosPadres.Enabled = false;
            this.txtFiltrosPadres.Font = new System.Drawing.Font("Arial", 7.75F);
            this.txtFiltrosPadres.Location = new System.Drawing.Point(268, 155);
            this.txtFiltrosPadres.MaxLength = 200;
            this.txtFiltrosPadres.Name = "txtFiltrosPadres";
            this.txtFiltrosPadres.ShortcutsEnabled = false;
            this.txtFiltrosPadres.Size = new System.Drawing.Size(244, 19);
            this.txtFiltrosPadres.TabIndex = 60;
            this.txtFiltrosPadres.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtFiltrosPadres.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txt_KeyUp);
            // 
            // lblBFCte
            // 
            this.lblBFCte.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblBFCte.Location = new System.Drawing.Point(313, 44);
            this.lblBFCte.Name = "lblBFCte";
            this.lblBFCte.Size = new System.Drawing.Size(318, 13);
            this.lblBFCte.TabIndex = 39;
            this.lblBFCte.Text = "Beneficiario Final";
            // 
            // lblFechaServer
            // 
            this.lblFechaServer.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblFechaServer.Location = new System.Drawing.Point(398, 9);
            this.lblFechaServer.Name = "lblFechaServer";
            this.lblFechaServer.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblFechaServer.Size = new System.Drawing.Size(252, 15);
            this.lblFechaServer.TabIndex = 37;
            this.lblFechaServer.Text = "Fecha Server";
            this.lblFechaServer.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblSaldoGlobalCte
            // 
            this.lblSaldoGlobalCte.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblSaldoGlobalCte.Location = new System.Drawing.Point(450, 132);
            this.lblSaldoGlobalCte.Name = "lblSaldoGlobalCte";
            this.lblSaldoGlobalCte.Size = new System.Drawing.Size(103, 13);
            this.lblSaldoGlobalCte.TabIndex = 35;
            this.lblSaldoGlobalCte.Text = "Saldo Global:";
            // 
            // lblBFCteN
            // 
            this.lblBFCteN.AutoSize = true;
            this.lblBFCteN.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblBFCteN.Location = new System.Drawing.Point(201, 44);
            this.lblBFCteN.Name = "lblBFCteN";
            this.lblBFCteN.Size = new System.Drawing.Size(103, 14);
            this.lblBFCteN.TabIndex = 38;
            this.lblBFCteN.Text = "Beneficiario Final:";
            // 
            // lblSaldoFavorCte
            // 
            this.lblSaldoFavorCte.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblSaldoFavorCte.Location = new System.Drawing.Point(287, 132);
            this.lblSaldoFavorCte.Name = "lblSaldoFavorCte";
            this.lblSaldoFavorCte.Size = new System.Drawing.Size(82, 13);
            this.lblSaldoFavorCte.TabIndex = 34;
            this.lblSaldoFavorCte.Text = "Saldo a Favor:";
            // 
            // lblComMayCte
            // 
            this.lblComMayCte.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblComMayCte.Location = new System.Drawing.Point(103, 132);
            this.lblComMayCte.Name = "lblComMayCte";
            this.lblComMayCte.Size = new System.Drawing.Size(98, 13);
            this.lblComMayCte.TabIndex = 33;
            this.lblComMayCte.Text = "Compra Mayor:";
            // 
            // lblSaldoGlobalCteN
            // 
            this.lblSaldoGlobalCteN.AutoSize = true;
            this.lblSaldoGlobalCteN.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblSaldoGlobalCteN.Location = new System.Drawing.Point(371, 132);
            this.lblSaldoGlobalCteN.Name = "lblSaldoGlobalCteN";
            this.lblSaldoGlobalCteN.Size = new System.Drawing.Size(77, 14);
            this.lblSaldoGlobalCteN.TabIndex = 32;
            this.lblSaldoGlobalCteN.Text = "Saldo Global:";
            // 
            // lblSaldoFavorCteN
            // 
            this.lblSaldoFavorCteN.AutoSize = true;
            this.lblSaldoFavorCteN.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblSaldoFavorCteN.Location = new System.Drawing.Point(201, 132);
            this.lblSaldoFavorCteN.Name = "lblSaldoFavorCteN";
            this.lblSaldoFavorCteN.Size = new System.Drawing.Size(82, 14);
            this.lblSaldoFavorCteN.TabIndex = 31;
            this.lblSaldoFavorCteN.Text = "Saldo a Favor:";
            // 
            // lblComMayCteN
            // 
            this.lblComMayCteN.AutoSize = true;
            this.lblComMayCteN.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblComMayCteN.Location = new System.Drawing.Point(6, 132);
            this.lblComMayCteN.Name = "lblComMayCteN";
            this.lblComMayCteN.Size = new System.Drawing.Size(91, 14);
            this.lblComMayCteN.TabIndex = 30;
            this.lblComMayCteN.Text = "Compra Mayor:";
            // 
            // lblCPCte
            // 
            this.lblCPCte.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblCPCte.Location = new System.Drawing.Point(450, 97);
            this.lblCPCte.Name = "lblCPCte";
            this.lblCPCte.Size = new System.Drawing.Size(84, 13);
            this.lblCPCte.TabIndex = 28;
            this.lblCPCte.Text = "CP:";
            // 
            // lblRCobCte
            // 
            this.lblRCobCte.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblRCobCte.Location = new System.Drawing.Point(450, 115);
            this.lblRCobCte.Name = "lblRCobCte";
            this.lblRCobCte.Size = new System.Drawing.Size(70, 13);
            this.lblRCobCte.TabIndex = 27;
            this.lblRCobCte.Text = "Ruta Cobro:";
            // 
            // lblTelMovCte
            // 
            this.lblTelMovCte.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblTelMovCte.Location = new System.Drawing.Point(271, 115);
            this.lblTelMovCte.Name = "lblTelMovCte";
            this.lblTelMovCte.Size = new System.Drawing.Size(98, 13);
            this.lblTelMovCte.TabIndex = 26;
            this.lblTelMovCte.Text = "Tel. Movil:";
            // 
            // lblTelPartCte
            // 
            this.lblTelPartCte.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblTelPartCte.Location = new System.Drawing.Point(103, 115);
            this.lblTelPartCte.Name = "lblTelPartCte";
            this.lblTelPartCte.Size = new System.Drawing.Size(98, 13);
            this.lblTelPartCte.TabIndex = 25;
            this.lblTelPartCte.Text = "Tel. Particular:";
            // 
            // lblEstadoCte
            // 
            this.lblEstadoCte.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblEstadoCte.Location = new System.Drawing.Point(72, 97);
            this.lblEstadoCte.Name = "lblEstadoCte";
            this.lblEstadoCte.Size = new System.Drawing.Size(134, 13);
            this.lblEstadoCte.TabIndex = 24;
            this.lblEstadoCte.Text = "Estado:";
            // 
            // lblPoblacionCte
            // 
            this.lblPoblacionCte.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblPoblacionCte.Location = new System.Drawing.Point(450, 79);
            this.lblPoblacionCte.Name = "lblPoblacionCte";
            this.lblPoblacionCte.Size = new System.Drawing.Size(181, 13);
            this.lblPoblacionCte.TabIndex = 23;
            this.lblPoblacionCte.Text = "Población:";
            // 
            // lblColCte
            // 
            this.lblColCte.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblColCte.Location = new System.Drawing.Point(72, 79);
            this.lblColCte.Name = "lblColCte";
            this.lblColCte.Size = new System.Drawing.Size(297, 13);
            this.lblColCte.TabIndex = 22;
            this.lblColCte.Text = "Colonia:";
            // 
            // lblDelegacionCte
            // 
            this.lblDelegacionCte.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblDelegacionCte.Location = new System.Drawing.Point(450, 61);
            this.lblDelegacionCte.Name = "lblDelegacionCte";
            this.lblDelegacionCte.Size = new System.Drawing.Size(181, 13);
            this.lblDelegacionCte.TabIndex = 21;
            this.lblDelegacionCte.Text = "Delegación:";
            // 
            // lblDomCte
            // 
            this.lblDomCte.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblDomCte.Location = new System.Drawing.Point(72, 61);
            this.lblDomCte.Name = "lblDomCte";
            this.lblDomCte.Size = new System.Drawing.Size(297, 13);
            this.lblDomCte.TabIndex = 20;
            this.lblDomCte.Text = "Domicilio:";
            // 
            // lblCGlobalCte
            // 
            this.lblCGlobalCte.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblCGlobalCte.Location = new System.Drawing.Point(72, 44);
            this.lblCGlobalCte.Name = "lblCGlobalCte";
            this.lblCGlobalCte.Size = new System.Drawing.Size(69, 13);
            this.lblCGlobalCte.TabIndex = 19;
            this.lblCGlobalCte.Text = "C. Global:";
            // 
            // lblNomCte
            // 
            this.lblNomCte.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblNomCte.Location = new System.Drawing.Point(267, 25);
            this.lblNomCte.Name = "lblNomCte";
            this.lblNomCte.Size = new System.Drawing.Size(297, 13);
            this.lblNomCte.TabIndex = 18;
            this.lblNomCte.Text = "Nombre:";
            // 
            // lblCte2
            // 
            this.lblCte2.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblCte2.Location = new System.Drawing.Point(72, 25);
            this.lblCte2.Name = "lblCte2";
            this.lblCte2.Size = new System.Drawing.Size(80, 13);
            this.lblCte2.TabIndex = 17;
            this.lblCte2.Text = "Cliente:";
            // 
            // lblCGlobalCteN
            // 
            this.lblCGlobalCteN.AutoSize = true;
            this.lblCGlobalCteN.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblCGlobalCteN.Location = new System.Drawing.Point(6, 44);
            this.lblCGlobalCteN.Name = "lblCGlobalCteN";
            this.lblCGlobalCteN.Size = new System.Drawing.Size(58, 14);
            this.lblCGlobalCteN.TabIndex = 16;
            this.lblCGlobalCteN.Text = "C. Global:";
            // 
            // lblCte2N
            // 
            this.lblCte2N.AutoSize = true;
            this.lblCte2N.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblCte2N.Location = new System.Drawing.Point(6, 25);
            this.lblCte2N.Name = "lblCte2N";
            this.lblCte2N.Size = new System.Drawing.Size(49, 14);
            this.lblCte2N.TabIndex = 15;
            this.lblCte2N.Text = "Cliente:";
            // 
            // lblRCobCteN
            // 
            this.lblRCobCteN.AutoSize = true;
            this.lblRCobCteN.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblRCobCteN.Location = new System.Drawing.Point(371, 115);
            this.lblRCobCteN.Name = "lblRCobCteN";
            this.lblRCobCteN.Size = new System.Drawing.Size(71, 14);
            this.lblRCobCteN.TabIndex = 14;
            this.lblRCobCteN.Text = "Ruta Cobro:";
            // 
            // lblTelMovCteN
            // 
            this.lblTelMovCteN.AutoSize = true;
            this.lblTelMovCteN.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblTelMovCteN.Location = new System.Drawing.Point(201, 115);
            this.lblTelMovCteN.Name = "lblTelMovCteN";
            this.lblTelMovCteN.Size = new System.Drawing.Size(61, 14);
            this.lblTelMovCteN.TabIndex = 13;
            this.lblTelMovCteN.Text = "Tel. Móvil:";
            // 
            // lblTelPartCteN
            // 
            this.lblTelPartCteN.AutoSize = true;
            this.lblTelPartCteN.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblTelPartCteN.Location = new System.Drawing.Point(6, 115);
            this.lblTelPartCteN.Name = "lblTelPartCteN";
            this.lblTelPartCteN.Size = new System.Drawing.Size(84, 14);
            this.lblTelPartCteN.TabIndex = 12;
            this.lblTelPartCteN.Text = "Tel. Particular:";
            // 
            // lblEstadoCteN
            // 
            this.lblEstadoCteN.AutoSize = true;
            this.lblEstadoCteN.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblEstadoCteN.Location = new System.Drawing.Point(6, 97);
            this.lblEstadoCteN.Name = "lblEstadoCteN";
            this.lblEstadoCteN.Size = new System.Drawing.Size(47, 14);
            this.lblEstadoCteN.TabIndex = 11;
            this.lblEstadoCteN.Text = "Estado:";
            // 
            // lblCPCteN
            // 
            this.lblCPCteN.AutoSize = true;
            this.lblCPCteN.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblCPCteN.Location = new System.Drawing.Point(372, 97);
            this.lblCPCteN.Name = "lblCPCteN";
            this.lblCPCteN.Size = new System.Drawing.Size(25, 14);
            this.lblCPCteN.TabIndex = 10;
            this.lblCPCteN.Text = "CP:";
            // 
            // lblPoblacionCteN
            // 
            this.lblPoblacionCteN.AutoSize = true;
            this.lblPoblacionCteN.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblPoblacionCteN.Location = new System.Drawing.Point(372, 79);
            this.lblPoblacionCteN.Name = "lblPoblacionCteN";
            this.lblPoblacionCteN.Size = new System.Drawing.Size(63, 14);
            this.lblPoblacionCteN.TabIndex = 9;
            this.lblPoblacionCteN.Text = "Población:";
            // 
            // lblColCteN
            // 
            this.lblColCteN.AutoSize = true;
            this.lblColCteN.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblColCteN.Location = new System.Drawing.Point(6, 79);
            this.lblColCteN.Name = "lblColCteN";
            this.lblColCteN.Size = new System.Drawing.Size(51, 14);
            this.lblColCteN.TabIndex = 8;
            this.lblColCteN.Text = "Colonia:";
            // 
            // lblDelegacionCteN
            // 
            this.lblDelegacionCteN.AutoSize = true;
            this.lblDelegacionCteN.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblDelegacionCteN.Location = new System.Drawing.Point(372, 61);
            this.lblDelegacionCteN.Name = "lblDelegacionCteN";
            this.lblDelegacionCteN.Size = new System.Drawing.Size(63, 14);
            this.lblDelegacionCteN.TabIndex = 7;
            this.lblDelegacionCteN.Text = "Municipio:";
            // 
            // lblDomCteN
            // 
            this.lblDomCteN.AutoSize = true;
            this.lblDomCteN.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblDomCteN.Location = new System.Drawing.Point(6, 61);
            this.lblDomCteN.Name = "lblDomCteN";
            this.lblDomCteN.Size = new System.Drawing.Size(60, 14);
            this.lblDomCteN.TabIndex = 6;
            this.lblDomCteN.Text = "Domicilio:";
            // 
            // lblNomCteN
            // 
            this.lblNomCteN.AutoSize = true;
            this.lblNomCteN.Font = new System.Drawing.Font("Arial", 7.75F, System.Drawing.FontStyle.Bold);
            this.lblNomCteN.Location = new System.Drawing.Point(201, 25);
            this.lblNomCteN.Name = "lblNomCteN";
            this.lblNomCteN.Size = new System.Drawing.Size(54, 14);
            this.lblNomCteN.TabIndex = 5;
            this.lblNomCteN.Text = "Nombre:";
            // 
            // pDoctos
            // 
            this.pDoctos.BackColor = System.Drawing.Color.White;
            this.pDoctos.Controls.Add(this.scDoctos);
            this.pDoctos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pDoctos.Location = new System.Drawing.Point(0, 0);
            this.pDoctos.Name = "pDoctos";
            this.pDoctos.Size = new System.Drawing.Size(1004, 298);
            this.pDoctos.TabIndex = 28;
            // 
            // scDoctos
            // 
            this.scDoctos.BackColor = System.Drawing.Color.White;
            this.scDoctos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.scDoctos.Cursor = System.Windows.Forms.Cursors.Default;
            this.scDoctos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scDoctos.Location = new System.Drawing.Point(0, 0);
            this.scDoctos.Name = "scDoctos";
            this.scDoctos.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // scDoctos.Panel1
            // 
            this.scDoctos.Panel1.Controls.Add(this.tcDoctos);
            this.scDoctos.Panel1.Controls.Add(this.pTotalesCte);
            // 
            // scDoctos.Panel2
            // 
            this.scDoctos.Panel2.Controls.Add(this.pHijos);
            this.scDoctos.Size = new System.Drawing.Size(1004, 298);
            this.scDoctos.SplitterDistance = 212;
            this.scDoctos.SplitterWidth = 10;
            this.scDoctos.TabIndex = 0;
            this.scDoctos.TabStop = false;
            // 
            // tcDoctos
            // 
            this.tcDoctos.Controls.Add(this.tpMenudeo);
            this.tcDoctos.Controls.Add(this.tpDima);
            this.tcDoctos.Controls.Add(this.tpInstituciones);
            this.tcDoctos.Controls.Add(this.tpMayoreo);
            this.tcDoctos.Controls.Add(this.tpApoyoCobDima);
            this.tcDoctos.Controls.Add(this.tpDineralia);
            this.tcDoctos.Controls.Add(this.tpCreditoEmpresario);
            this.tcDoctos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tcDoctos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tcDoctos.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.tcDoctos.Location = new System.Drawing.Point(0, 0);
            this.tcDoctos.Name = "tcDoctos";
            this.tcDoctos.SelectedIndex = 0;
            this.tcDoctos.Size = new System.Drawing.Size(1000, 173);
            this.tcDoctos.TabIndex = 19;
            this.tcDoctos.Tag = "";
            this.tcDoctos.SelectedIndexChanged += new System.EventHandler(this.tcDoctos_SelectedIndexChanged);
            this.tcDoctos.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tcDoctos_Selecting);
            // 
            // tpMenudeo
            // 
            this.tpMenudeo.Controls.Add(this.pPadres);
            this.tpMenudeo.Location = new System.Drawing.Point(4, 23);
            this.tpMenudeo.Name = "tpMenudeo";
            this.tpMenudeo.Padding = new System.Windows.Forms.Padding(3);
            this.tpMenudeo.Size = new System.Drawing.Size(992, 146);
            this.tpMenudeo.TabIndex = 0;
            this.tpMenudeo.Tag = "1";
            this.tpMenudeo.Text = "MENUDEO";
            this.tpMenudeo.UseVisualStyleBackColor = true;
            // 
            // pPadres
            // 
            this.pPadres.AutoScroll = true;
            this.pPadres.BackColor = System.Drawing.SystemColors.Control;
            this.pPadres.Controls.Add(this.dgvPadres);
            this.pPadres.Controls.Add(this.ssTotalesTab);
            this.pPadres.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pPadres.Location = new System.Drawing.Point(3, 3);
            this.pPadres.Name = "pPadres";
            this.pPadres.Size = new System.Drawing.Size(986, 140);
            this.pPadres.TabIndex = 0;
            // 
            // dgvPadres
            // 
            this.dgvPadres.AllowUserToAddRows = false;
            this.dgvPadres.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgvPadres.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvPadres.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvPadres.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvPadres.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvPadres.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPadres.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvPadres.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPadres.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.IdVta,
            this.PadreMAVI,
            this.PadreIDMAVI,
            this.CteFinal,
            this.NombreBeneficiarioFinal,
            this.MovimientoPadre,
            this.DiaPago,
            this.LiquidaCon,
            this.PagoParaEstaralCorriente,
            this.ImporteApoyo,
            this.SaldoApoyo,
            this.ImporteaPagar,
            this.ACondonar,
            this.DescripciondelArticulo,
            this.SolicitarApoyo});
            this.dgvPadres.ContextMenuStrip = this.cmsMenuPadres;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPadres.DefaultCellStyle = dataGridViewCellStyle9;
            this.dgvPadres.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvPadres.EnableHeadersVisualStyles = false;
            this.dgvPadres.Location = new System.Drawing.Point(0, 0);
            this.dgvPadres.MultiSelect = false;
            this.dgvPadres.Name = "dgvPadres";
            this.dgvPadres.RowHeadersVisible = false;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.DeepSkyBlue;
            this.dgvPadres.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.dgvPadres.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvPadres.Size = new System.Drawing.Size(986, 118);
            this.dgvPadres.TabIndex = 2;
            this.dgvPadres.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPadres_CellEndEdit);
            this.dgvPadres.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvPadres_ColumnHeaderMouseClick);
            this.dgvPadres.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dgvPadres_DataBindingComplete);
            this.dgvPadres.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgvPadres_DataError);
            this.dgvPadres.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvPadres_EditingControlShowing);
            this.dgvPadres.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPadres_RowEnter);
            this.dgvPadres.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dgvPadres_KeyDown);
            // 
            // ID
            // 
            this.ID.DataPropertyName = "ID";
            this.ID.Frozen = true;
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.Visible = false;
            this.ID.Width = 23;
            // 
            // IdVta
            // 
            this.IdVta.DataPropertyName = "IdVta";
            this.IdVta.Frozen = true;
            this.IdVta.HeaderText = "IdVta";
            this.IdVta.Name = "IdVta";
            this.IdVta.ReadOnly = true;
            this.IdVta.Visible = false;
            this.IdVta.Width = 41;
            // 
            // PadreMAVI
            // 
            this.PadreMAVI.DataPropertyName = "PadreMAVI";
            this.PadreMAVI.Frozen = true;
            this.PadreMAVI.HeaderText = "PadreMAVI";
            this.PadreMAVI.Name = "PadreMAVI";
            this.PadreMAVI.ReadOnly = true;
            this.PadreMAVI.Visible = false;
            this.PadreMAVI.Width = 73;
            // 
            // PadreIDMAVI
            // 
            this.PadreIDMAVI.DataPropertyName = "PadreIDMAVI";
            this.PadreIDMAVI.Frozen = true;
            this.PadreIDMAVI.HeaderText = "PadreIDMAVI";
            this.PadreIDMAVI.Name = "PadreIDMAVI";
            this.PadreIDMAVI.ReadOnly = true;
            this.PadreIDMAVI.Visible = false;
            this.PadreIDMAVI.Width = 83;
            // 
            // CteFinal
            // 
            this.CteFinal.DataPropertyName = "CteFinal";
            this.CteFinal.Frozen = true;
            this.CteFinal.HeaderText = "CteFinal";
            this.CteFinal.Name = "CteFinal";
            this.CteFinal.ReadOnly = true;
            this.CteFinal.Visible = false;
            this.CteFinal.Width = 57;
            // 
            // NombreBeneficiarioFinal
            // 
            this.NombreBeneficiarioFinal.DataPropertyName = "NomCteFinal";
            this.NombreBeneficiarioFinal.Frozen = true;
            this.NombreBeneficiarioFinal.HeaderText = "Nombre Beneficiario Final";
            this.NombreBeneficiarioFinal.Name = "NombreBeneficiarioFinal";
            this.NombreBeneficiarioFinal.ReadOnly = true;
            this.NombreBeneficiarioFinal.Width = 134;
            // 
            // MovimientoPadre
            // 
            this.MovimientoPadre.DataPropertyName = "Movimiento";
            this.MovimientoPadre.Frozen = true;
            this.MovimientoPadre.HeaderText = "Movimiento";
            this.MovimientoPadre.Name = "MovimientoPadre";
            this.MovimientoPadre.ReadOnly = true;
            this.MovimientoPadre.Width = 97;
            // 
            // DiaPago
            // 
            this.DiaPago.DataPropertyName = "DiaPago";
            this.DiaPago.HeaderText = "Día Pago";
            this.DiaPago.Name = "DiaPago";
            this.DiaPago.ReadOnly = true;
            this.DiaPago.Width = 72;
            // 
            // LiquidaCon
            // 
            this.LiquidaCon.DataPropertyName = "PagoLiquida";
            dataGridViewCellStyle3.Format = "C2";
            this.LiquidaCon.DefaultCellStyle = dataGridViewCellStyle3;
            this.LiquidaCon.HeaderText = "Liquida Con";
            this.LiquidaCon.Name = "LiquidaCon";
            this.LiquidaCon.ReadOnly = true;
            this.LiquidaCon.Width = 89;
            // 
            // PagoParaEstaralCorriente
            // 
            this.PagoParaEstaralCorriente.DataPropertyName = "PagoParaEstaralCorriente";
            dataGridViewCellStyle4.Format = "C2";
            this.PagoParaEstaralCorriente.DefaultCellStyle = dataGridViewCellStyle4;
            this.PagoParaEstaralCorriente.HeaderText = "Pago Para Estar al Corriente";
            this.PagoParaEstaralCorriente.Name = "PagoParaEstaralCorriente";
            this.PagoParaEstaralCorriente.ReadOnly = true;
            this.PagoParaEstaralCorriente.Width = 121;
            // 
            // ImporteApoyo
            // 
            this.ImporteApoyo.DataPropertyName = "ImpApoyo";
            dataGridViewCellStyle5.Format = "C2";
            this.ImporteApoyo.DefaultCellStyle = dataGridViewCellStyle5;
            this.ImporteApoyo.HeaderText = "Importe Apoyo";
            this.ImporteApoyo.Name = "ImporteApoyo";
            this.ImporteApoyo.ReadOnly = true;
            this.ImporteApoyo.Width = 105;
            // 
            // SaldoApoyo
            // 
            this.SaldoApoyo.DataPropertyName = "SaldoApoyo";
            dataGridViewCellStyle6.Format = "C2";
            this.SaldoApoyo.DefaultCellStyle = dataGridViewCellStyle6;
            this.SaldoApoyo.HeaderText = "Saldo Apoyo";
            this.SaldoApoyo.Name = "SaldoApoyo";
            this.SaldoApoyo.ReadOnly = true;
            this.SaldoApoyo.Width = 92;
            // 
            // ImporteaPagar
            // 
            this.ImporteaPagar.DataPropertyName = "ImportePagar";
            dataGridViewCellStyle7.Format = "C2";
            this.ImporteaPagar.DefaultCellStyle = dataGridViewCellStyle7;
            this.ImporteaPagar.HeaderText = "Captura Importe a Pagar";
            this.ImporteaPagar.Name = "ImporteaPagar";
            this.ImporteaPagar.Width = 123;
            // 
            // ACondonar
            // 
            this.ACondonar.DataPropertyName = "ACondonar";
            dataGridViewCellStyle8.Format = "C2";
            this.ACondonar.DefaultCellStyle = dataGridViewCellStyle8;
            this.ACondonar.HeaderText = "A Condonar";
            this.ACondonar.Name = "ACondonar";
            this.ACondonar.Width = 89;
            // 
            // DescripciondelArticulo
            // 
            this.DescripciondelArticulo.DataPropertyName = "DescripcionArt";
            this.DescripciondelArticulo.HeaderText = "Descripción del Articulo";
            this.DescripciondelArticulo.Name = "DescripciondelArticulo";
            this.DescripciondelArticulo.ReadOnly = true;
            this.DescripciondelArticulo.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.DescripciondelArticulo.Width = 110;
            // 
            // SolicitarApoyo
            // 
            this.SolicitarApoyo.DataPropertyName = "SolicitarApoyo";
            this.SolicitarApoyo.HeaderText = "Solicitar Apoyo";
            this.SolicitarApoyo.Name = "SolicitarApoyo";
            this.SolicitarApoyo.Width = 86;
            // 
            // cmsMenuPadres
            // 
            this.cmsMenuPadres.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.cmsMenuPadres.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnVerDetalle,
            this.btnOcultaDetalle});
            this.cmsMenuPadres.Name = "cmsMenuPadres";
            this.cmsMenuPadres.Size = new System.Drawing.Size(170, 48);
            this.cmsMenuPadres.Opening += new System.ComponentModel.CancelEventHandler(this.cmsMenuPadres_Opening);
            // 
            // btnVerDetalle
            // 
            this.btnVerDetalle.MergeIndex = 1;
            this.btnVerDetalle.Name = "btnVerDetalle";
            this.btnVerDetalle.Size = new System.Drawing.Size(169, 22);
            this.btnVerDetalle.Text = "Ver Detalle";
            this.btnVerDetalle.Click += new System.EventHandler(this.cmsMenuPadres_btn_ClickAsync);
            // 
            // btnOcultaDetalle
            // 
            this.btnOcultaDetalle.MergeIndex = 2;
            this.btnOcultaDetalle.Name = "btnOcultaDetalle";
            this.btnOcultaDetalle.Size = new System.Drawing.Size(169, 22);
            this.btnOcultaDetalle.Text = "Ocultar Detalle";
            this.btnOcultaDetalle.Click += new System.EventHandler(this.cmsMenuPadres_btn_ClickAsync);
            // 
            // ssTotalesTab
            // 
            this.ssTotalesTab.AutoSize = false;
            this.ssTotalesTab.BackColor = System.Drawing.Color.AliceBlue;
            this.ssTotalesTab.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblTotalesCatCte,
            this.lblTabDoctos,
            this.lblTabCteFinalN,
            this.lblTabCteFinal,
            this.lblTabImpVtaN,
            this.lblTabImpVta,
            this.lblTabSaldoCapitalN,
            this.lblTabSaldoCapital,
            this.lblTabMoratoriosN,
            this.lblTabMoratorios,
            this.lblTabSaldoTotalN,
            this.lblTabSaldoTotal,
            this.lblTabSaldoVencidoN,
            this.lblTabSaldoVencido});
            this.ssTotalesTab.Location = new System.Drawing.Point(0, 118);
            this.ssTotalesTab.Name = "ssTotalesTab";
            this.ssTotalesTab.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.ssTotalesTab.Size = new System.Drawing.Size(986, 22);
            this.ssTotalesTab.TabIndex = 4;
            this.ssTotalesTab.Text = "ssTotalesTab";
            // 
            // lblTotalesCatCte
            // 
            this.lblTotalesCatCte.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblTotalesCatCte.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblTotalesCatCte.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblTotalesCatCte.Name = "lblTotalesCatCte";
            this.lblTotalesCatCte.Size = new System.Drawing.Size(50, 17);
            this.lblTotalesCatCte.Text = "TOTAL ";
            // 
            // lblTabDoctos
            // 
            this.lblTabDoctos.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblTabDoctos.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblTabDoctos.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblTabDoctos.Name = "lblTabDoctos";
            this.lblTabDoctos.Size = new System.Drawing.Size(17, 17);
            this.lblTabDoctos.Text = "0";
            this.lblTabDoctos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTabCteFinalN
            // 
            this.lblTabCteFinalN.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblTabCteFinalN.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblTabCteFinalN.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblTabCteFinalN.Name = "lblTabCteFinalN";
            this.lblTabCteFinalN.Size = new System.Drawing.Size(58, 17);
            this.lblTabCteFinalN.Text = "Cte Final";
            // 
            // lblTabCteFinal
            // 
            this.lblTabCteFinal.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblTabCteFinal.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblTabCteFinal.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblTabCteFinal.Name = "lblTabCteFinal";
            this.lblTabCteFinal.Size = new System.Drawing.Size(17, 17);
            this.lblTabCteFinal.Text = "0";
            this.lblTabCteFinal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTabImpVtaN
            // 
            this.lblTabImpVtaN.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblTabImpVtaN.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblTabImpVtaN.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblTabImpVtaN.Name = "lblTabImpVtaN";
            this.lblTabImpVtaN.Size = new System.Drawing.Size(89, 17);
            this.lblTabImpVtaN.Text = "Importe Venta";
            // 
            // lblTabImpVta
            // 
            this.lblTabImpVta.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblTabImpVta.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblTabImpVta.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblTabImpVta.Name = "lblTabImpVta";
            this.lblTabImpVta.Size = new System.Drawing.Size(17, 17);
            this.lblTabImpVta.Text = "0";
            this.lblTabImpVta.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTabSaldoCapitalN
            // 
            this.lblTabSaldoCapitalN.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblTabSaldoCapitalN.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblTabSaldoCapitalN.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblTabSaldoCapitalN.Name = "lblTabSaldoCapitalN";
            this.lblTabSaldoCapitalN.Size = new System.Drawing.Size(81, 17);
            this.lblTabSaldoCapitalN.Text = "Saldo Capital";
            // 
            // lblTabSaldoCapital
            // 
            this.lblTabSaldoCapital.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblTabSaldoCapital.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblTabSaldoCapital.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblTabSaldoCapital.Name = "lblTabSaldoCapital";
            this.lblTabSaldoCapital.Size = new System.Drawing.Size(17, 17);
            this.lblTabSaldoCapital.Text = "0";
            this.lblTabSaldoCapital.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTabMoratoriosN
            // 
            this.lblTabMoratoriosN.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblTabMoratoriosN.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblTabMoratoriosN.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblTabMoratoriosN.Name = "lblTabMoratoriosN";
            this.lblTabMoratoriosN.Size = new System.Drawing.Size(72, 17);
            this.lblTabMoratoriosN.Text = "Moratorios";
            // 
            // lblTabMoratorios
            // 
            this.lblTabMoratorios.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblTabMoratorios.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblTabMoratorios.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblTabMoratorios.Name = "lblTabMoratorios";
            this.lblTabMoratorios.Size = new System.Drawing.Size(17, 17);
            this.lblTabMoratorios.Text = "0";
            this.lblTabMoratorios.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTabSaldoTotalN
            // 
            this.lblTabSaldoTotalN.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblTabSaldoTotalN.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblTabSaldoTotalN.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblTabSaldoTotalN.Name = "lblTabSaldoTotalN";
            this.lblTabSaldoTotalN.Size = new System.Drawing.Size(70, 17);
            this.lblTabSaldoTotalN.Text = "Saldo Total";
            // 
            // lblTabSaldoTotal
            // 
            this.lblTabSaldoTotal.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblTabSaldoTotal.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblTabSaldoTotal.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblTabSaldoTotal.Name = "lblTabSaldoTotal";
            this.lblTabSaldoTotal.Size = new System.Drawing.Size(17, 17);
            this.lblTabSaldoTotal.Text = "0";
            this.lblTabSaldoTotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTabSaldoVencidoN
            // 
            this.lblTabSaldoVencidoN.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblTabSaldoVencidoN.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblTabSaldoVencidoN.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblTabSaldoVencidoN.Name = "lblTabSaldoVencidoN";
            this.lblTabSaldoVencidoN.Size = new System.Drawing.Size(88, 17);
            this.lblTabSaldoVencidoN.Text = "Saldo Vencido";
            // 
            // lblTabSaldoVencido
            // 
            this.lblTabSaldoVencido.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblTabSaldoVencido.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblTabSaldoVencido.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblTabSaldoVencido.Name = "lblTabSaldoVencido";
            this.lblTabSaldoVencido.Size = new System.Drawing.Size(17, 17);
            this.lblTabSaldoVencido.Text = "0";
            this.lblTabSaldoVencido.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tpDima
            // 
            this.tpDima.Location = new System.Drawing.Point(4, 23);
            this.tpDima.Name = "tpDima";
            this.tpDima.Padding = new System.Windows.Forms.Padding(3);
            this.tpDima.Size = new System.Drawing.Size(992, 146);
            this.tpDima.TabIndex = 1;
            this.tpDima.Tag = "2";
            this.tpDima.Text = "DIMA";
            this.tpDima.UseVisualStyleBackColor = true;
            // 
            // tpInstituciones
            // 
            this.tpInstituciones.Location = new System.Drawing.Point(4, 23);
            this.tpInstituciones.Name = "tpInstituciones";
            this.tpInstituciones.Padding = new System.Windows.Forms.Padding(3);
            this.tpInstituciones.Size = new System.Drawing.Size(992, 146);
            this.tpInstituciones.TabIndex = 2;
            this.tpInstituciones.Tag = "3";
            this.tpInstituciones.Text = "INSTITUCIONES";
            this.tpInstituciones.UseVisualStyleBackColor = true;
            // 
            // tpMayoreo
            // 
            this.tpMayoreo.Location = new System.Drawing.Point(4, 23);
            this.tpMayoreo.Name = "tpMayoreo";
            this.tpMayoreo.Padding = new System.Windows.Forms.Padding(3);
            this.tpMayoreo.Size = new System.Drawing.Size(992, 146);
            this.tpMayoreo.TabIndex = 3;
            this.tpMayoreo.Tag = "4";
            this.tpMayoreo.Text = "MAYOREO";
            this.tpMayoreo.UseVisualStyleBackColor = true;
            // 
            // tpApoyoCobDima
            // 
            this.tpApoyoCobDima.Location = new System.Drawing.Point(4, 23);
            this.tpApoyoCobDima.Name = "tpApoyoCobDima";
            this.tpApoyoCobDima.Padding = new System.Windows.Forms.Padding(3);
            this.tpApoyoCobDima.Size = new System.Drawing.Size(992, 146);
            this.tpApoyoCobDima.TabIndex = 5;
            this.tpApoyoCobDima.Tag = "5";
            this.tpApoyoCobDima.Text = "APOYO COBRANZA DIMA";
            this.tpApoyoCobDima.UseVisualStyleBackColor = true;
            // 
            // tpDineralia
            // 
            this.tpDineralia.Location = new System.Drawing.Point(4, 23);
            this.tpDineralia.Name = "tpDineralia";
            this.tpDineralia.Size = new System.Drawing.Size(992, 146);
            this.tpDineralia.TabIndex = 6;
            this.tpDineralia.Tag = "6";
            this.tpDineralia.Text = "DINERALIA";
            this.tpDineralia.UseVisualStyleBackColor = true;
            // 
            // tpCreditoEmpresario
            // 
            this.tpCreditoEmpresario.Location = new System.Drawing.Point(4, 23);
            this.tpCreditoEmpresario.Name = "tpCreditoEmpresario";
            this.tpCreditoEmpresario.Size = new System.Drawing.Size(992, 146);
            this.tpCreditoEmpresario.TabIndex = 7;
            this.tpCreditoEmpresario.Tag = "7";
            this.tpCreditoEmpresario.Text = "CREDILANA EMPRESARIO";
            this.tpCreditoEmpresario.UseVisualStyleBackColor = true;
            // 
            // pTotalesCte
            // 
            this.pTotalesCte.BackColor = System.Drawing.SystemColors.Control;
            this.pTotalesCte.Controls.Add(this.ssTotalesCte);
            this.pTotalesCte.Controls.Add(this.lblTotalesCte);
            this.pTotalesCte.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pTotalesCte.Location = new System.Drawing.Point(0, 173);
            this.pTotalesCte.Name = "pTotalesCte";
            this.pTotalesCte.Size = new System.Drawing.Size(1000, 35);
            this.pTotalesCte.TabIndex = 20;
            // 
            // ssTotalesCte
            // 
            this.ssTotalesCte.AutoSize = false;
            this.ssTotalesCte.BackColor = System.Drawing.SystemColors.Control;
            this.ssTotalesCte.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblTotDoctos,
            this.lblTotImpVtaN,
            this.lblTotImpVta,
            this.lblTotSaldoCapitalN,
            this.lblTotSaldoCapital,
            this.lblTotMoratoriosN,
            this.lblTotMoratorios,
            this.lblTotSaldoTotalN,
            this.lblTotSaldoTotal,
            this.lblTotSaldoVencidoN,
            this.lblTotSaldoVencido});
            this.ssTotalesCte.Location = new System.Drawing.Point(0, 13);
            this.ssTotalesCte.Name = "ssTotalesCte";
            this.ssTotalesCte.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.ssTotalesCte.Size = new System.Drawing.Size(1000, 22);
            this.ssTotalesCte.TabIndex = 17;
            this.ssTotalesCte.Text = "ssTotalesCte";
            // 
            // lblTotDoctos
            // 
            this.lblTotDoctos.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblTotDoctos.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblTotDoctos.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblTotDoctos.Name = "lblTotDoctos";
            this.lblTotDoctos.Size = new System.Drawing.Size(17, 17);
            this.lblTotDoctos.Text = "0";
            this.lblTotDoctos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTotImpVtaN
            // 
            this.lblTotImpVtaN.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblTotImpVtaN.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblTotImpVtaN.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblTotImpVtaN.Name = "lblTotImpVtaN";
            this.lblTotImpVtaN.Size = new System.Drawing.Size(89, 17);
            this.lblTotImpVtaN.Text = "Importe Venta";
            // 
            // lblTotImpVta
            // 
            this.lblTotImpVta.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblTotImpVta.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblTotImpVta.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblTotImpVta.Name = "lblTotImpVta";
            this.lblTotImpVta.Size = new System.Drawing.Size(17, 17);
            this.lblTotImpVta.Text = "0";
            this.lblTotImpVta.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTotSaldoCapitalN
            // 
            this.lblTotSaldoCapitalN.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblTotSaldoCapitalN.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblTotSaldoCapitalN.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblTotSaldoCapitalN.Name = "lblTotSaldoCapitalN";
            this.lblTotSaldoCapitalN.Size = new System.Drawing.Size(81, 17);
            this.lblTotSaldoCapitalN.Text = "Saldo Capital";
            // 
            // lblTotSaldoCapital
            // 
            this.lblTotSaldoCapital.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblTotSaldoCapital.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblTotSaldoCapital.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblTotSaldoCapital.Name = "lblTotSaldoCapital";
            this.lblTotSaldoCapital.Size = new System.Drawing.Size(17, 17);
            this.lblTotSaldoCapital.Text = "0";
            this.lblTotSaldoCapital.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTotMoratoriosN
            // 
            this.lblTotMoratoriosN.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblTotMoratoriosN.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblTotMoratoriosN.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblTotMoratoriosN.Name = "lblTotMoratoriosN";
            this.lblTotMoratoriosN.Size = new System.Drawing.Size(72, 17);
            this.lblTotMoratoriosN.Text = "Moratorios";
            // 
            // lblTotMoratorios
            // 
            this.lblTotMoratorios.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblTotMoratorios.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblTotMoratorios.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblTotMoratorios.Name = "lblTotMoratorios";
            this.lblTotMoratorios.Size = new System.Drawing.Size(17, 17);
            this.lblTotMoratorios.Text = "0";
            this.lblTotMoratorios.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTotSaldoTotalN
            // 
            this.lblTotSaldoTotalN.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblTotSaldoTotalN.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblTotSaldoTotalN.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblTotSaldoTotalN.Name = "lblTotSaldoTotalN";
            this.lblTotSaldoTotalN.Size = new System.Drawing.Size(70, 17);
            this.lblTotSaldoTotalN.Text = "Saldo Total";
            // 
            // lblTotSaldoTotal
            // 
            this.lblTotSaldoTotal.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblTotSaldoTotal.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblTotSaldoTotal.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblTotSaldoTotal.Name = "lblTotSaldoTotal";
            this.lblTotSaldoTotal.Size = new System.Drawing.Size(17, 17);
            this.lblTotSaldoTotal.Text = "0";
            this.lblTotSaldoTotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTotSaldoVencidoN
            // 
            this.lblTotSaldoVencidoN.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblTotSaldoVencidoN.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblTotSaldoVencidoN.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblTotSaldoVencidoN.Name = "lblTotSaldoVencidoN";
            this.lblTotSaldoVencidoN.Size = new System.Drawing.Size(88, 17);
            this.lblTotSaldoVencidoN.Text = "Saldo Vencido";
            // 
            // lblTotSaldoVencido
            // 
            this.lblTotSaldoVencido.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblTotSaldoVencido.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblTotSaldoVencido.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblTotSaldoVencido.Name = "lblTotSaldoVencido";
            this.lblTotSaldoVencido.Size = new System.Drawing.Size(17, 17);
            this.lblTotSaldoVencido.Text = "0";
            this.lblTotSaldoVencido.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTotalesCte
            // 
            this.lblTotalesCte.AutoSize = true;
            this.lblTotalesCte.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold);
            this.lblTotalesCte.Location = new System.Drawing.Point(6, 1);
            this.lblTotalesCte.Name = "lblTotalesCte";
            this.lblTotalesCte.Size = new System.Drawing.Size(150, 15);
            this.lblTotalesCte.TabIndex = 16;
            this.lblTotalesCte.Text = "TOTAL GENERAL CLIENTE";
            // 
            // pHijos
            // 
            this.pHijos.Controls.Add(this.dgvHijos);
            this.pHijos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pHijos.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pHijos.Location = new System.Drawing.Point(0, 0);
            this.pHijos.Name = "pHijos";
            this.pHijos.Size = new System.Drawing.Size(1000, 72);
            this.pHijos.TabIndex = 4;
            // 
            // dgvHijos
            // 
            this.dgvHijos.AllowUserToAddRows = false;
            this.dgvHijos.AllowUserToDeleteRows = false;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dgvHijos.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
            this.dgvHijos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvHijos.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvHijos.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvHijos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvHijos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dgvHijos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHijos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Movimiento,
            this.Vencimiento,
            this.Importe,
            this.ImporteCPP,
            this.Saldo,
            this.DiasVencidos,
            this.Origen,
            this.SaldoApoyoDIMA});
            this.dgvHijos.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvHijos.DefaultCellStyle = dataGridViewCellStyle18;
            this.dgvHijos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvHijos.EnableHeadersVisualStyles = false;
            this.dgvHijos.Location = new System.Drawing.Point(0, 0);
            this.dgvHijos.MultiSelect = false;
            this.dgvHijos.Name = "dgvHijos";
            this.dgvHijos.ReadOnly = true;
            this.dgvHijos.RowHeadersVisible = false;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.Color.DeepSkyBlue;
            this.dgvHijos.RowsDefaultCellStyle = dataGridViewCellStyle19;
            this.dgvHijos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHijos.Size = new System.Drawing.Size(1000, 72);
            this.dgvHijos.TabIndex = 3;
            // 
            // Movimiento
            // 
            this.Movimiento.DataPropertyName = "Movimiento";
            this.Movimiento.HeaderText = "Movimiento";
            this.Movimiento.Name = "Movimiento";
            this.Movimiento.ReadOnly = true;
            this.Movimiento.Width = 97;
            // 
            // Vencimiento
            // 
            this.Vencimiento.DataPropertyName = "Vencimiento";
            this.Vencimiento.HeaderText = "Vencimiento";
            this.Vencimiento.Name = "Vencimiento";
            this.Vencimiento.ReadOnly = true;
            this.Vencimiento.Width = 101;
            // 
            // Importe
            // 
            this.Importe.DataPropertyName = "ImporteTotal";
            dataGridViewCellStyle13.Format = "C2";
            this.Importe.DefaultCellStyle = dataGridViewCellStyle13;
            this.Importe.HeaderText = "Pago Normal";
            this.Importe.Name = "Importe";
            this.Importe.ReadOnly = true;
            this.Importe.Width = 93;
            // 
            // ImporteCPP
            // 
            this.ImporteCPP.DataPropertyName = "BonifPP_Round";
            dataGridViewCellStyle14.Format = "C2";
            this.ImporteCPP.DefaultCellStyle = dataGridViewCellStyle14;
            this.ImporteCPP.HeaderText = "Pago Puntual";
            this.ImporteCPP.Name = "ImporteCPP";
            this.ImporteCPP.ReadOnly = true;
            this.ImporteCPP.Width = 95;
            // 
            // Saldo
            // 
            this.Saldo.DataPropertyName = "Saldo";
            dataGridViewCellStyle15.Format = "C2";
            this.Saldo.DefaultCellStyle = dataGridViewCellStyle15;
            this.Saldo.HeaderText = "Saldo";
            this.Saldo.Name = "Saldo";
            this.Saldo.ReadOnly = true;
            this.Saldo.Width = 62;
            // 
            // DiasVencidos
            // 
            this.DiasVencidos.DataPropertyName = "DiasVencidos";
            dataGridViewCellStyle16.Format = "N0";
            this.DiasVencidos.DefaultCellStyle = dataGridViewCellStyle16;
            this.DiasVencidos.HeaderText = "Días Vencidos";
            this.DiasVencidos.Name = "DiasVencidos";
            this.DiasVencidos.ReadOnly = true;
            // 
            // Origen
            // 
            this.Origen.DataPropertyName = "Origen";
            this.Origen.HeaderText = "Origen";
            this.Origen.Name = "Origen";
            this.Origen.ReadOnly = true;
            this.Origen.Width = 69;
            // 
            // SaldoApoyoDIMA
            // 
            this.SaldoApoyoDIMA.DataPropertyName = "SaldoApoyoDima";
            dataGridViewCellStyle17.Format = "C2";
            this.SaldoApoyoDIMA.DefaultCellStyle = dataGridViewCellStyle17;
            this.SaldoApoyoDIMA.HeaderText = "Saldo Apoyo DIMA";
            this.SaldoApoyoDIMA.Name = "SaldoApoyoDIMA";
            this.SaldoApoyoDIMA.ReadOnly = true;
            this.SaldoApoyoDIMA.Width = 120;
            // 
            // ssPreliminar
            // 
            this.ssPreliminar.BackColor = System.Drawing.Color.AliceBlue;
            this.ssPreliminar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblUsuarioN,
            this.lblUsuario,
            this.lblNombreN,
            this.lblNombre,
            this.lblSucTrabajoN,
            this.lblSucTrabajo,
            this.lblEstTrabajoN,
            this.lblEstTrabajo,
            this.lblServerBase,
            this.lblVersionApp});
            this.ssPreliminar.Location = new System.Drawing.Point(0, 623);
            this.ssPreliminar.Name = "ssPreliminar";
            this.ssPreliminar.Size = new System.Drawing.Size(1008, 25);
            this.ssPreliminar.TabIndex = 25;
            this.ssPreliminar.Text = "statusStrip1";
            // 
            // lblUsuarioN
            // 
            this.lblUsuarioN.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblUsuarioN.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblUsuarioN.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblUsuarioN.Name = "lblUsuarioN";
            this.lblUsuarioN.Size = new System.Drawing.Size(56, 20);
            this.lblUsuarioN.Text = "Usuario:";
            // 
            // lblUsuario
            // 
            this.lblUsuario.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblUsuario.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblUsuario.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblUsuario.Name = "lblUsuario";
            this.lblUsuario.Size = new System.Drawing.Size(41, 20);
            this.lblUsuario.Text = "          ";
            // 
            // lblNombreN
            // 
            this.lblNombreN.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblNombreN.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblNombreN.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblNombreN.Name = "lblNombreN";
            this.lblNombreN.Size = new System.Drawing.Size(58, 20);
            this.lblNombreN.Text = "Nombre:";
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = false;
            this.lblNombre.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblNombre.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblNombre.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(250, 20);
            // 
            // lblSucTrabajoN
            // 
            this.lblSucTrabajoN.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblSucTrabajoN.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblSucTrabajoN.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblSucTrabajoN.Name = "lblSucTrabajoN";
            this.lblSucTrabajoN.Size = new System.Drawing.Size(105, 20);
            this.lblSucTrabajoN.Text = "Sucursal Trabajo:";
            // 
            // lblSucTrabajo
            // 
            this.lblSucTrabajo.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblSucTrabajo.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblSucTrabajo.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblSucTrabajo.Name = "lblSucTrabajo";
            this.lblSucTrabajo.Size = new System.Drawing.Size(23, 20);
            this.lblSucTrabajo.Text = "    ";
            // 
            // lblEstTrabajoN
            // 
            this.lblEstTrabajoN.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblEstTrabajoN.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblEstTrabajoN.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblEstTrabajoN.Name = "lblEstTrabajoN";
            this.lblEstTrabajoN.Size = new System.Drawing.Size(103, 20);
            this.lblEstTrabajoN.Text = "Estacion Trabajo:";
            // 
            // lblEstTrabajo
            // 
            this.lblEstTrabajo.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblEstTrabajo.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblEstTrabajo.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblEstTrabajo.Name = "lblEstTrabajo";
            this.lblEstTrabajo.Size = new System.Drawing.Size(23, 20);
            this.lblEstTrabajo.Text = "    ";
            // 
            // lblServerBase
            // 
            this.lblServerBase.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblServerBase.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblServerBase.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblServerBase.Name = "lblServerBase";
            this.lblServerBase.Size = new System.Drawing.Size(129, 20);
            this.lblServerBase.Text = "000.000.000:IntelisisTmp";
            // 
            // lblVersionApp
            // 
            this.lblVersionApp.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.lblVersionApp.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.lblVersionApp.Font = new System.Drawing.Font("Arial", 7.75F);
            this.lblVersionApp.Name = "lblVersionApp";
            this.lblVersionApp.Size = new System.Drawing.Size(78, 20);
            this.lblVersionApp.Text = "lblVersionApp";
            // 
            // frmPreliminarCobro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1008, 648);
            this.Controls.Add(this.scGeneral);
            this.Controls.Add(this.ssPreliminar);
            this.Controls.Add(this.pFiltros);
            this.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "frmPreliminarCobro";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Preliminar de Cobro";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmPreliminarCobro_FormClosing);
            this.Load += new System.EventHandler(this.frmPrincipal_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmPreliminarCobro_KeyDown);
            this.pFiltros.ResumeLayout(false);
            this.pFiltros.PerformLayout();
            this.scGeneral.Panel1.ResumeLayout(false);
            this.scGeneral.Panel1.PerformLayout();
            this.scGeneral.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.scGeneral)).EndInit();
            this.scGeneral.ResumeLayout(false);
            this.gbInfoCte.ResumeLayout(false);
            this.gbInfoCte.PerformLayout();
            this.pGeneraCobro.ResumeLayout(false);
            this.pGeneraCobro.PerformLayout();
            this.pDoctos.ResumeLayout(false);
            this.scDoctos.Panel1.ResumeLayout(false);
            this.scDoctos.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.scDoctos)).EndInit();
            this.scDoctos.ResumeLayout(false);
            this.tcDoctos.ResumeLayout(false);
            this.tpMenudeo.ResumeLayout(false);
            this.pPadres.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPadres)).EndInit();
            this.cmsMenuPadres.ResumeLayout(false);
            this.ssTotalesTab.ResumeLayout(false);
            this.ssTotalesTab.PerformLayout();
            this.pTotalesCte.ResumeLayout(false);
            this.pTotalesCte.PerformLayout();
            this.ssTotalesCte.ResumeLayout(false);
            this.ssTotalesCte.PerformLayout();
            this.pHijos.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvHijos)).EndInit();
            this.ssPreliminar.ResumeLayout(false);
            this.ssPreliminar.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblCteBusca;
        private System.Windows.Forms.Panel pFiltros;
        private System.Windows.Forms.TextBox txtCteBusca;
        private System.Windows.Forms.Button btnVerGenerarCobro;
        private System.Windows.Forms.Label lblCteNomBusca;
        private System.Windows.Forms.TextBox txtCteNomBusca;
        private System.Windows.Forms.Label lblCteDirBusca;
        private System.Windows.Forms.TextBox txtCteDirBusca;
        private System.Windows.Forms.Label lblCteTelBusca;
        private System.Windows.Forms.TextBox txtCteTelBusca;
        private System.Windows.Forms.Label lblCteCPBusca;
        private System.Windows.Forms.TextBox txtCteCPBusca;
        private System.Windows.Forms.Label lblCobXPolitica;
        private System.Windows.Forms.Label lblConvLCT;
        private System.Windows.Forms.Label lblHuellaSHM;
        private System.Windows.Forms.SplitContainer scGeneral;
        private System.Windows.Forms.Panel pDoctos;
        private System.Windows.Forms.SplitContainer scDoctos;
        private System.Windows.Forms.TabControl tcDoctos;
        private System.Windows.Forms.TabPage tpMenudeo;
        private System.Windows.Forms.TabPage tpDima;
        private System.Windows.Forms.TabPage tpInstituciones;
        private System.Windows.Forms.TabPage tpMayoreo;
        private System.Windows.Forms.TabPage tpApoyoCobDima;
        private System.Windows.Forms.DataGridView dgvHijos;
        private System.Windows.Forms.GroupBox gbInfoCte;
        private System.Windows.Forms.Label lblCPCte;
        private System.Windows.Forms.Label lblRCobCte;
        private System.Windows.Forms.Label lblTelMovCte;
        private System.Windows.Forms.Label lblTelPartCte;
        private System.Windows.Forms.Label lblEstadoCte;
        private System.Windows.Forms.Label lblPoblacionCte;
        private System.Windows.Forms.Label lblColCte;
        private System.Windows.Forms.Label lblDelegacionCte;
        private System.Windows.Forms.Label lblDomCte;
        private System.Windows.Forms.Label lblCGlobalCte;
        private System.Windows.Forms.Label lblNomCte;
        private System.Windows.Forms.Label lblCte2;
        private System.Windows.Forms.Label lblCGlobalCteN;
        private System.Windows.Forms.Label lblCte2N;
        private System.Windows.Forms.Label lblRCobCteN;
        private System.Windows.Forms.Label lblTelMovCteN;
        private System.Windows.Forms.Label lblTelPartCteN;
        private System.Windows.Forms.Label lblEstadoCteN;
        private System.Windows.Forms.Label lblCPCteN;
        private System.Windows.Forms.Label lblPoblacionCteN;
        private System.Windows.Forms.Label lblColCteN;
        private System.Windows.Forms.Label lblDelegacionCteN;
        private System.Windows.Forms.Label lblDomCteN;
        private System.Windows.Forms.Label lblNomCteN;
        private System.Windows.Forms.StatusStrip ssPreliminar;
        private System.Windows.Forms.ToolStripStatusLabel lblUsuarioN;
        private System.Windows.Forms.ToolStripStatusLabel lblUsuario;
        private System.Windows.Forms.ToolStripStatusLabel lblNombreN;
        private System.Windows.Forms.ToolStripStatusLabel lblNombre;
        private System.Windows.Forms.ToolStripStatusLabel lblSucTrabajoN;
        private System.Windows.Forms.ToolStripStatusLabel lblSucTrabajo;
        private System.Windows.Forms.ToolStripStatusLabel lblEstTrabajoN;
        private System.Windows.Forms.ToolStripStatusLabel lblEstTrabajo;
        private System.Windows.Forms.ToolStripStatusLabel lblServerBase;
        private System.Windows.Forms.Label lblComMayCteN;
        private System.Windows.Forms.Label lblSaldoFavorCteN;
        private System.Windows.Forms.Label lblSaldoGlobalCteN;
        private System.Windows.Forms.Label lblSaldoGlobalCte;
        private System.Windows.Forms.Label lblSaldoFavorCte;
        private System.Windows.Forms.Label lblComMayCte;
        private System.Windows.Forms.Panel pPadres;
        private System.Windows.Forms.DataGridView dgvPadres;
        private System.Windows.Forms.StatusStrip ssTotalesTab;
        private System.Windows.Forms.ContextMenuStrip cmsMenuPadres;
        private System.Windows.Forms.ToolStripMenuItem btnVerDetalle;
        private System.Windows.Forms.ToolStripMenuItem btnOcultaDetalle;
        private System.Windows.Forms.Label lblFechaServer;
        private System.Windows.Forms.ToolStripStatusLabel lblTabDoctos;
        private System.Windows.Forms.ToolStripStatusLabel lblTabImpVtaN;
        private System.Windows.Forms.ToolStripStatusLabel lblTabImpVta;
        private System.Windows.Forms.ToolStripStatusLabel lblTabSaldoCapitalN;
        private System.Windows.Forms.ToolStripStatusLabel lblTabSaldoCapital;
        private System.Windows.Forms.ToolStripStatusLabel lblTabMoratoriosN;
        private System.Windows.Forms.ToolStripStatusLabel lblTabMoratorios;
        private System.Windows.Forms.ToolStripStatusLabel lblTabSaldoVencidoN;
        private System.Windows.Forms.ToolStripStatusLabel lblTabSaldoVencido;
        private System.Windows.Forms.ToolStripStatusLabel lblTabSaldoTotalN;
        private System.Windows.Forms.ToolStripStatusLabel lblTabSaldoTotal;
        private System.Windows.Forms.Panel pTotalesCte;
        private System.Windows.Forms.Panel pHijos;
        private System.Windows.Forms.Label lblTotalesCte;
        private System.Windows.Forms.StatusStrip ssTotalesCte;
        private System.Windows.Forms.ToolStripStatusLabel lblTotDoctos;
        private System.Windows.Forms.ToolStripStatusLabel lblTotImpVtaN;
        private System.Windows.Forms.ToolStripStatusLabel lblTotImpVta;
        private System.Windows.Forms.ToolStripStatusLabel lblTotSaldoCapitalN;
        private System.Windows.Forms.ToolStripStatusLabel lblTotSaldoCapital;
        private System.Windows.Forms.ToolStripStatusLabel lblTotMoratoriosN;
        private System.Windows.Forms.ToolStripStatusLabel lblTotMoratorios;
        private System.Windows.Forms.ToolStripStatusLabel lblTotSaldoVencidoN;
        private System.Windows.Forms.ToolStripStatusLabel lblTotSaldoVencido;
        private System.Windows.Forms.ToolStripStatusLabel lblTotSaldoTotalN;
        private System.Windows.Forms.ToolStripStatusLabel lblTotSaldoTotal;
        private System.Windows.Forms.Button btnHerramientas;
        private System.Windows.Forms.Label lblTiempoConsulta;
        private System.Windows.Forms.TextBox txtTiempoConsulta;
        private System.Windows.Forms.ToolStripStatusLabel lblVersionApp;
        private System.Windows.Forms.CheckBox cbBF;
        private System.Windows.Forms.Label lblBFCteN;
        private System.Windows.Forms.Label lblBFCte;
        private System.Windows.Forms.Panel pGeneraCobro;
        private System.Windows.Forms.ToolStripStatusLabel lblTabCteFinalN;
        private System.Windows.Forms.ToolStripStatusLabel lblTabCteFinal;
        private System.Windows.Forms.Label lblFiltrosPadres;
        private System.Windows.Forms.Label lblCteIntervenido;
        private System.Windows.Forms.TextBox txtFiltrosPadres;
        private System.Windows.Forms.Label lblMovCobroN;
        private System.Windows.Forms.Label lblMovIdCobroN;
        private System.Windows.Forms.Label lblFormaPagoN;
        private System.Windows.Forms.ComboBox cbFormaPago;
        private System.Windows.Forms.Label lblTotalCobrarN;
        private System.Windows.Forms.TextBox txtTotalCobrar;
        private System.Windows.Forms.TextBox txtImporteRecibido;
        private System.Windows.Forms.Label lblImporteRecibidoN;
        private System.Windows.Forms.TextBox txtCambio;
        private System.Windows.Forms.Label lblCambioN;
        private System.Windows.Forms.TextBox txtMovIdCobro;
        private System.Windows.Forms.TextBox txtCobro;
        private System.Windows.Forms.Button btnAutCondonacion;
        private System.Windows.Forms.Button btnQuitaSeguro;
        private System.Windows.Forms.Label lblPadreFechaEmision;
        private System.Windows.Forms.TextBox txtPadreUltPago;
        private System.Windows.Forms.Label lblPadreDiasInactivo;
        private System.Windows.Forms.Label lblPadrePago;
        private System.Windows.Forms.TextBox txtPadreFechaEmision;
        private System.Windows.Forms.Label lblPadreSaldoTotal;
        private System.Windows.Forms.TextBox txtPadreCondicion;
        private System.Windows.Forms.Label lblPadreSaldoVencido;
        private System.Windows.Forms.TextBox txtPadre1erVenc;
        private System.Windows.Forms.Label lblPadreMoratorios;
        private System.Windows.Forms.TextBox txtPadreSucursal;
        private System.Windows.Forms.Label lblPadreSaldoCapital;
        private System.Windows.Forms.TextBox txtPadreDiasInactivo;
        private System.Windows.Forms.Label lblPadreImpVta;
        private System.Windows.Forms.TextBox txtPadreCanalVenta;
        private System.Windows.Forms.Label lblPadreCanalVenta;
        private System.Windows.Forms.TextBox txtPadreImpVta;
        private System.Windows.Forms.TextBox txtPadreSaldoCapital;
        private System.Windows.Forms.Label lblPadreSucursal;
        private System.Windows.Forms.TextBox txtPadreMoratorios;
        private System.Windows.Forms.Label lblPadre1erVenc;
        private System.Windows.Forms.TextBox txtPadreSaldoVencido;
        private System.Windows.Forms.Label lblPadreUltPago;
        private System.Windows.Forms.TextBox txtPadreSaldoTotal;
        private System.Windows.Forms.Label lblPadreCondicion;
        private System.Windows.Forms.TextBox txtPadrePago;
        private System.Windows.Forms.Label lblPadreDiasVencido;
        private System.Windows.Forms.TextBox txtPadreDiasVencido;
        private System.Windows.Forms.Button btnSalirCobro;
        private System.Windows.Forms.Button btnCancelaCobro;
        private System.Windows.Forms.Button btnGenerarCobros;
        private System.Windows.Forms.TextBox txtPadreCobXPolitica;
        private System.Windows.Forms.Label lblPadreCobXPolitica;
        private System.Windows.Forms.ToolStripStatusLabel lblTotalesCatCte;
        private System.Windows.Forms.DataGridViewTextBoxColumn Movimiento;
        private System.Windows.Forms.DataGridViewTextBoxColumn Vencimiento;
        private System.Windows.Forms.DataGridViewTextBoxColumn Importe;
        private System.Windows.Forms.DataGridViewTextBoxColumn ImporteCPP;
        private System.Windows.Forms.DataGridViewTextBoxColumn Saldo;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiasVencidos;
        private System.Windows.Forms.DataGridViewTextBoxColumn Origen;
        private System.Windows.Forms.DataGridViewTextBoxColumn SaldoApoyoDIMA;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn IdVta;
        private System.Windows.Forms.DataGridViewTextBoxColumn PadreMAVI;
        private System.Windows.Forms.DataGridViewTextBoxColumn PadreIDMAVI;
        private System.Windows.Forms.DataGridViewTextBoxColumn CteFinal;
        private System.Windows.Forms.DataGridViewTextBoxColumn NombreBeneficiarioFinal;
        private System.Windows.Forms.DataGridViewTextBoxColumn MovimientoPadre;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiaPago;
        private System.Windows.Forms.DataGridViewTextBoxColumn LiquidaCon;
        private System.Windows.Forms.DataGridViewTextBoxColumn PagoParaEstaralCorriente;
        private System.Windows.Forms.DataGridViewTextBoxColumn ImporteApoyo;
        private System.Windows.Forms.DataGridViewTextBoxColumn SaldoApoyo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ImporteaPagar;
        private System.Windows.Forms.DataGridViewTextBoxColumn ACondonar;
        private System.Windows.Forms.DataGridViewTextBoxColumn DescripciondelArticulo;
        private System.Windows.Forms.DataGridViewCheckBoxColumn SolicitarApoyo;
        private System.Windows.Forms.TextBox txtPadreNHijos;
        private System.Windows.Forms.Label lblPadreNHijos;
        private System.Windows.Forms.TabPage tpDineralia;
        private System.Windows.Forms.TabPage tpCreditoEmpresario;
        private System.Windows.Forms.TextBox txtPadreBonificacion;
        private System.Windows.Forms.Label lblPadreBonificacion;
        private System.Windows.Forms.TextBox txtPadreConvLCT;
        private System.Windows.Forms.Label lblPadreConvLCT;
        private System.Windows.Forms.Label lblCtaAsignada;
        private System.Windows.Forms.Label lblConvRD;
    }
}